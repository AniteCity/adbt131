package game;

import city.cs.engine.*;
import game.Controls.Keyboard;
import game.GUI.BestScore;
import game.Levels.*;
import game.View.GameView;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

/**
 * A world with some bodies.
 */
public class Game {

    /** The World in which the bodies move and interact. */

    //Declaring variables
    private GameWorld level;
    private GameView view;
    private Keyboard keyboard;
    private final JFrame frame;
    private Frame frame2;
    private Frame frame3;
    private JFrame debugView;
    private SoundClip gameMusic;
    private int overallScore;



    /** Initialise a new Game. */
    public Game() {

        //Instantiated and initialised a new object level
        level = new Level1(this);



        //Instantiated and initialised a new object view by calling the GameView constructor
        view = new GameView(level, 500, 500,level.getHero1(),level);


        //Adds a background track
        backgroundMusicAndBackground(level);



        //Creates frame and frame2 objects
        frame = new JFrame("My First Game");
        frame2 = new JFrame();
        frame3 = new JFrame();


        //Update the properties for the frame3
        frame3 = new JFrame();
        frame3.pack();
        frame3.isUndecorated();
        frame3.setVisible(false);
        frame3.setAlwaysOnTop(true);
        frame3.setLocation(200,250);
        frame3.setSize(142,350);
        frame3.add(level.getButtons().getMainPanel(),BorderLayout.WEST);



        // add the view to a frame (Java top level window)
        frame.add(view);

        /*Adds a key listener on the frame*/
        frame.addKeyListener(level.getKeyboard());



        // when the x button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
        // finally, make the frame visible
        frame.setVisible(true);

        // uncomment this to make a debugging view
        debugView = new DebugViewer(level, 500, 500);

        /* Properties for frame2 - Sets its size, location, position, and adds the buttons from the GUI*/
        frame2();

        //take the focus from that window
        debugView.setFocusableWindowState(false);


        // start our game world simulation!
        level.start();
    }

    //Method to check if the Key was picked and to shift to the next level

    public int goToNextLevel(boolean key){



        if (level instanceof Level1 && key==true){


            stopBeforeLevel();

            //Assign level to level2
            level = new Level2(this);
            view.setLevelName("Level 2");
            playAfterLevel();


        } else if (level instanceof Level2 && key==true){

            //stops the level,music and the frame2
            stopBeforeLevel();

            //Assign level to level2
            level = new Level3(this);
            view.setLevelName("Level 3");
            playAfterLevel();


        }else if (level instanceof Level3 && key==true){

            stopBeforeLevel();
            //assign the level to a new level
            level = new Level4(this);
            view.setLevelName("Level 4");
            playAfterLevel();


        }else if (level instanceof Level4 && key==true){
            JDialog diaScore = new JDialog(frame3,true);
            BestScore highScore = new BestScore(this);
            diaScore.getContentPane().add(highScore.getJpanelScores());

            diaScore.pack();
            diaScore.setVisible(true);
        }
        return 0;
    }


    //Stopping the level, music, dispose the frame and update the score.
    public void stopBeforeLevel(){
        //stop the level, music and close the frame2 window
        level.stop();
        gameMusic.stop();
        frame2.dispose();
        debugView.dispose();

        overallScore=level.getHero1().getThunderCount();
    }

    //Playing the level, music, dispose the frame and update the score.
    public void playAfterLevel(){
        level.getHero1().setThunderCount(overallScore);

        //Reset the Flame,key and the lives
        resetIcons();

        //update the view to the new world
        view.setWorld(level);

        //add a background music
        backgroundMusicAndBackground(this.level);

        //update the keyboard to the new level
        frame.addKeyListener(level.getKeyboard());
        debugView = new DebugViewer(level, 500, 500);

        debugView.setFocusableWindowState(false);



        view.setHero1(level.getHero1());

        frame2();

        //Start the level
        level.start();

    }



    //Getter Method for the view variable
    public GameView getView() {
        return view;
    }

    //Getter Method for the gamemusic variable
    public SoundClip getGameMusic() {
        return gameMusic;
    }

    //set all the icons on the screen to reset
    public void resetIcons(){

        getView().setFlame( new ImageIcon("").getImage());
        getView().setKey( new ImageIcon("").getImage());
        getView().set3Lives();
    }


    //method to play background music depending on which level the player is and set the background image.
    public  SoundClip backgroundMusicAndBackground(GameWorld Level) {

        if(this.level.getLevelName() == "Level1") {//checks if the level is on Level1

            view.setBackground(new ImageIcon("data/background.gif").getImage());//sets the background image
            try {
                gameMusic = new SoundClip("data/Level1BackgroundMusic.wav");   // Open an audio input stream
                // Set it to continous playback (looping)
                gameMusic.setVolume(0.080f); //sets the volume of the music
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                System.out.println(e);
            }
            //loop the track
            gameMusic.loop();

        }else if(this.level.getLevelName() == "Level2") {

            view.setBackground(new ImageIcon("data/background2.gif").getImage());
            try {
                gameMusic = new SoundClip("data/Level2BackgroundMusic.wav");   // Open an audio input stream
                // Set it to continous playback (looping)
                gameMusic.setVolume(0.080f);
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                System.out.println(e);
            }
            //loop the track
            gameMusic.loop();

        }else if(this.level.getLevelName() == "Level3") {

            view.setBackground(new ImageIcon("data/background3.gif").getImage());
            try {
                gameMusic = new SoundClip("data/Level3BackgroundMusic.wav");   // Open an audio input stream

                gameMusic.setVolume(0.080f);
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                System.out.println(e);
            }
            //loop the track
            gameMusic.loop();

        }else if(this.level.getLevelName() == "Level4") {

            view.setBackground(new ImageIcon("data/background4.gif").getImage());
            try {
                gameMusic = new SoundClip("data/Level4BackgroundMusic.wav");   // Open an audio input stream

                gameMusic.setVolume(0.080f);
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                System.out.println(e);
            }
            //loop the track
            gameMusic.loop();

        }
        return gameMusic;
    }





    //method to stop the level
    public void gamePause(){
        level.stop();

    }

    //method to resume the level
    public void gameResume(){
        level.start();


    }

    //Getter Method for the frame2 variable
    public Frame getFrame2() {
        return frame2;
    }

    //method to quit the game
    public void gameQuit(){
        System.exit(0);
    }





    //method to get the level
    public GameWorld getLevel() {
        return level;
    }


    //method to set the level.
    public void setLevel(GameWorld level){


        //stop the level, music and close the frame2 window
        debugView.dispose();
        this.level.stop();
        gameMusic.stop();
        frame2.dispose();


        //Assign level to level2
        this.level = level;

        //Reset the Flame,key and the lives


        //update the view to the new world
        view.setWorld(level);

        //add a background music
        backgroundMusicAndBackground(this.level);

        //update the keyboard to the new level
        frame.addKeyListener(level.getKeyboard());
        debugView = new DebugViewer(level, 500, 500);

        debugView.setFocusableWindowState(false);

        //set a new background and update the hero1
        view.setHero1(level.getHero1());

        //calls the frame2 method
        frame2();


        //Start the level
        this.level.start();

    }


    //method to create a Jframe for pause menu purpose
    public void frame2(){

        /*Update the properties for the frame2*/
        frame2 = new JFrame();
        frame2.pack();
        frame2.isUndecorated();
        frame2.setVisible(false);
        frame2.setAlwaysOnTop(true);
        frame2.setLocation(200,250);
        frame2.setSize(142,350);
        frame2.add(level.getButtons().getMainPanel(),BorderLayout.WEST);
        frame2.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if(level.getButtons().getChecked()==1 ){


                    if(level.getButtons().getTickbox()==0) {
                        gameResume();
                        frame2.setVisible(false);
                        getGameMusic().play();
                        frame2.setFocusableWindowState(false);

                        level.getButtons().setChecked(0);
                    }else if(level.getButtons().getTickbox()==1){
                        gameResume();
                        frame2.setVisible(false);
                        getGameMusic().stop();
                        level.getSounds().stopJumpSound();
                        getFrame2().setFocusableWindowState(false);

                        level.getButtons().setChecked(0);

                    }



                }
            }

        });
    }

    /** Run the game. */
    public static void main(String[] args) {

        new Game();
    }
}