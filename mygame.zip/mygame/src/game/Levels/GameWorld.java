package game.Levels;

import city.cs.engine.World;
import game.Ammos.Fireball;
import game.Collect.Collect;
import game.Collectable.*;
import game.Construnction.Platform_Level1;
import game.Construnction.Platform_Level2;
import game.Construnction.Platform_Level3;
import game.Construnction.Platform_Level4;
import game.GUI.ControlPanel;
import game.Controls.Keyboard;
import game.Game;
import game.GameCharacters.Enemy1;
import game.GameCharacters.Enemy2;
import game.GameCharacters.Hero1;
import game.Shoot.Shooting;
import game.Sounds.Sounds;
import game.View.GameView;
import org.jbox2d.common.Vec2;

import javax.swing.text.View;
import java.awt.*;

//Creating a class called GameWorld which extends the properties from the World Class
/**
 * This class is a blueprint to create a level. It will make sure each level have same
 * common characteristics between all the levels
 *
 * @author Anite Cangi
 * @version 1.0
 * @see game.View.GameView
 * @see ControlPanel
 */
public abstract class GameWorld extends World {



    //Declaring all tha variables
    private Platform_Level1 plat1;
    private Platform_Level2 plat2;
    private Platform_Level3 plat3;
    private Platform_Level4 plat4;
    private Enemy1 enemy1;
    private Lives lives;
    private Hero1 hero1;
    private Thunder points;
    private Door door;
    private Collect collect;
    private Key key;
    private Fire fire;
    private Spike spike;
    private Sounds sounds;
    private ControlPanel buttons;
    private Frame frame2;
    private Game game;
    private Trampoline trampoline;
    private float enemy1Speed = 5;
    private float enemy2Speed = 5;
    private Keyboard keyboard;
    private MovingSpike movingSpike1;
    private MovingSpike movingSpike2;
    private MovingSpike movingSpike3;
    private Enemy2 enemy2;
    private int firecount;



    //Creating a constructor which will receive Game variable type

    /**
     * The GameWorld constructor is responsible for initializing all the objects inside any level.
     *
     * @param g The "g" variable will obtain the game class for the constructor.
     */
    public GameWorld(Game g) {

        //Instantiating the variables and creating new objects
        hero1 = new Hero1(this);
        lives = new Lives(this);
        door = new Door(this);
        key = new Key(this);
        sounds = new Sounds();
        enemy1 = new Enemy1(this);
        game =g;
        buttons = new ControlPanel(g,this.sounds,this);
        keyboard = new Keyboard(hero1,this,g,buttons,g.getFrame2());
        collect = new Collect(hero1,g,key,door,this,sounds,keyboard);

    }

    /**
     * The getView is a getter method to obtain the view from the Game Class.
     *
     * @return It return the GameView from the Game class.
     */
    public GameView getView() {

        return game.getView();
    }

    /*Getter methods for the moving spikes to obtain only the object without instantiating a
    new object or adding a listener*/
    /**
     * The getOnlyMovingSpike1 is a getter method to solely obtain the object MovingSpike1
     *
     * @return It return the object movingSpike1
     */
    public MovingSpike getOnlyMovingSpike1() {

        return movingSpike1;
    }

    /**
     * The getOnlyMovingSpike2 is a getter method to solely obtain the object MovingSpike2
     *
     * @return It return the object movingSpike2
     */
    public MovingSpike getOnlyMovingSpike2() {

        return movingSpike2;
    }

    /**
     * The getOnlyMovingSpike2 is a getter method to solely obtain the object movingSpike3
     *
     * @return movingSpike3
     */
    public MovingSpike getOnlyMovingSpike3() {

        return movingSpike3;
    }


    /*Creating 3 methods to create MovingSpike of type objects with a listener which detects any collision*/

    /**
     * The getMovingSpike1 creates a new object of type MovingSpike every time is called with an Collision Listener.
     *
     * @return It return movingSpike1 object with the collision listener.
     */
    public MovingSpike getMovingSpike1() {
        movingSpike1 = new MovingSpike(this);
        movingSpike1.addCollisionListener(collect);

        return movingSpike1;
    }

    /**
     * The getMovingSpike2 creates a new object of type MovingSpike every time is called with an Collision Listener.
     *
     * @return It return movingSpike2 object with the collision listener.
     */
    public MovingSpike getMovingSpike2() {
        movingSpike2 = new MovingSpike(this);
        movingSpike2.addCollisionListener(collect);

        return movingSpike2;
    }

    /**
     * The getMovingSpike3 creates a new object of type MovingSpike every time is called with an Collision Listener.
     *
     * @return It return movingSpike3 object with the collision listener.
     */
    public MovingSpike getMovingSpike3() {
        movingSpike3 = new MovingSpike(this);
        movingSpike3.addCollisionListener(collect);

        return movingSpike3;
    }

    //This method adds Linear Velocity on the 3 MovingSpike objects
    /**
     * The method getMovingSpikeUp is responsible to add linear velocity in vertical.
     */
    public void getMovingSpikeUp() {

        movingSpike1.setLinearVelocity(new Vec2(0,10));
        movingSpike2.setLinearVelocity(new Vec2(0,10));
        movingSpike3.setLinearVelocity(new Vec2(0,10));
    }


    //Creating a method which will create a new object enemy2, adding collision listener and linear velocity
    /**
     * The getEnemy2 method is responsible to create a new Enemy2 Object everytime is called with
     * a collision listener and a initial velocity horizontally attached.
     *
     * @return It return enemy2 object with a collision listener and a initial linear velocity horizontally.
     */
    public Enemy2 getEnemy2() {
        enemy2 = new Enemy2(this);
        enemy2.setLinearVelocity(new Vec2(enemy2Speed,0));
        enemy2.addCollisionListener(getCollect());
        enemy2.addCollisionListener(new Shooting(enemy1,this));

        return enemy2;
    }


    //Getter method for only the Enemy2
    /**
     * The getOnlyEnemy2 is a getter method which is responsible to the Enemy2 object only without creating
     * a new object everytime is called.
     *
     * @return It return solely enemy2.
     */
    public Enemy2 getOnlyEnemy2() {

        return enemy2;
    }


    /*Methods to flip the image of the Enemy2 to the left and right hand side*/
    /**
     * The getEnemy2RImage method is responsible to flip the image of the Enemy2 to the Right hand side.
     */
    public void getEnemy2RImage() {
        enemy2.flipRight();
    }

    /**
     * The getEnemy2LImage method is responsible to flip the image of the Enemy2 to the Left hand side.
     */
    public void getEnemy2LImage() {
        enemy2.flipLeft();
    }

    //Method to make the enemy2 start walking
    /**
     * The setEnemy2Walking is a method which is responsible to start the Enemy2
     * walking with a velocity to everytime the method is called.
     *
     * @param speed Is responsible to obtain a speed value to set the walking speed of the Enemy2.
     */
    public void setEnemy2Walking(float speed) {
        enemy2.startWalking(speed);
    }

    //Setter method to set the speed the Enemy2 will walk

    /**
     * The setEnemy2Speed is a setter method which is responsible to set a value to the enemy2 speed.
     *
     * @param enemy2Speed It receives a value which will set the local variable of the Enemy2Speed of the Enemy2.
     */
    public void setEnemy2Speed(float enemy2Speed) {
        this.enemy2Speed = enemy2Speed;
    }

    //Getter method for the Enemy2 speed.
    /**
     * The getEnemy2Speed is a getter method which is responsible to get the speed of the Enemy2.
     *
     * @return It returns the speed of the Enemy2.
     */
    public float getEnemy2Speed() {
        return enemy2Speed;
    }

    //Method to create an Trampoline Object and add a collision listener

    /**
     * The getTrampoline is a method that creates a new trampoline Object everytime that is called and attaches a
     * collision listener.
     *
     * @return It returns the trampoline Object with the collision listener attached.
     */
    public Trampoline getTrampoline() {
        trampoline = new Trampoline(this);
        trampoline.addCollisionListener(getCollect());
        return trampoline;
    }




    //Getter method for the keyboard

    /**
     * The getKeyboard is a getter method which gets the keyboard Object.
     *
     * @return It returns the Keyboard Object which is initialised on the constructor.
     */
    public Keyboard getKeyboard() {
        return keyboard;
    }




    //Getter method for the Frame2
    /**
     * The getFrame2 is a getter method which responsible to get the Frame2 object from the Game class
     *
     * @return It returns game.getFrame2 which obtained from the Game class.
     */
    public Frame getFrame2() {
        return game.getFrame2();
    }

    //Getter method for the game object
    /**
     * The getGame method is a getter method which is responsible to get the game class attributes.
     *
     * @return It returns the game object.
     */
    public Game getGame() {
        return game;
    }

    //Getter method for the buttons object
    /**
     * The getButtons method is a getter method which is responsible to get the buttons object.
     *
     * @return It returns the buttons Object
     */
    public ControlPanel getButtons() {
        return buttons;
    }

    //Getter method for the sounds Object
    /**
     * The getSounds method is a getter method which is responsible to obtain the sounds Object.
     *
     * @return It returns the Sounds Object.
     */
    public Sounds getSounds() {
        return sounds;
    }

    //Method to make the Enemy1 start walking and add a collision listener
    /**
     * The getEnemy1 is a method which adds a collision listener and makes the Enemy1 walk when its called.
     *
     * @return It returns the Enemy1 Object with the collision listener and the walking speed set.
     */
    public Enemy1 getEnemy1() {

        enemy1.addCollisionListener(collect);
        enemy1.startWalking(enemy1Speed);

        return enemy1;
    }


    //Setter method for the speed of the Enemy1
    /**
     * The setEnemy1Speed is a setter method which is responsible to obtain a value and set it to the Enemy1's speed
     *
     * @param enemy1Speed It receives a value to set the speed of the Enemy1 Object.
     */
    public void setEnemy1Speed(float enemy1Speed) {
        this.enemy1Speed = enemy1Speed;
    }


    //Method to create a Spike object and a collision listener
    /**
     * The getSpike is a method which creates a new spike object and adds a collision listener whenever is called.
     *
     * @return It return the Object spike with the collision listener added.
     */
    public Spike getSpike() {
        spike = new Spike(this);
        spike.addCollisionListener(getCollect());
        return spike;
    }

    /*Methods to create a platform Objects*/
    /**
     * The Platform_Level4 is a method which is responsible to create a new object of type Platform_Level4
     * everytime is called.
     *
     * @return It returns the plat4 Object.
     */
    public Platform_Level4 getPlat4() {
        plat4 = new Platform_Level4(this);
        return plat4;
    }

    /**
     * The Platform_Level3 is a method which is responsible to create a new object of type Platform_Level3
     * everytime is called.
     *
     * @return It returns the plat3 Object.
     */
    public Platform_Level3 getPlat3() {
        plat3 = new Platform_Level3(this);
        return plat3;
    }

    /**
     * The Platform_Level2 is a method which is responsible to create a new object of type Platform_Level2
     * everytime is called.
     *
     * @return It returns the plat2 Object.
     */
    public Platform_Level2 getPlat2() {
        plat2 = new Platform_Level2(this);
        return plat2;
    }

    /**
     * The Platform_Level1 is a method which is responsible to create a new object of type Platform_Level1
     * everytime is called.
     *
     * @return It returns the plat1 Object.
     */
    public Platform_Level1 getPlat1() {
        plat1 = new Platform_Level1(this);
        return plat1;
    }


    //Method to create a Fire object with a collision listener
    /**
     * The getFire is a method which is responsible to create a new object of type Fire
     * everytime is called with a collision listener attached.
     *
     * @return It returns the fire Object.
     */
    public Fire getFire() {
        fire = new Fire(this);
        fire.addCollisionListener(getCollect());
        return fire;
    }


    //Method to increase the firecount
    /**
     * The increaseFireCount is a method which is responsible to increase the Fire count by 1 everytime is called.
     *
     */
    public void increaseFireCount() {

        fire.incrementFireCount();

    }

    //Method to decrease the enemy2life
    /**
     * The decreaseEnemy2LifeCount is a method which is responsible to decrease the Enemy2 life count
     * by 1 everytime is called.
     *
     */
    public void decreaseEnemy2LifeCount() {

        enemy2.decrementEnemy2Life();

    }

    //Method to decrease the Fire count
    /**
     * The decreaseFireCount is a method which is responsible to decrease the Fire count by 1 everytime is called.
     *
     */
    public void decreaseFireCount() {

        fire.decrementFireCount();

    }

    //Getter method for the fire Count variable
    /**
     *  The getFireCount is a getter method which is responsible to get the Fire count value.
     *
     * @return It return the value of the firecount value.
     */
    public int getFireCount() {

        firecount= fire.getFireCount();
        return firecount;
    }



    //Getter method for the door variable
    /**
     *  The getDoor is a getter method which is responsible to get the door object.
     *
     * @return It returns the door object.
     */
    public Door getDoor() {
        return door;
    }

    //Getter method for the key variable
    /**
     *  The getKey is a getter method which is responsible to get the key object.
     *
     * @return It returns the key object.
     */
    public Key getKey() {
        return key;
    }





    //Getter method to get the lives object
    /**
     *  The getLives is a getter method which is responsible to get the lives object.
     *
     * @return It returns the lives object.
     */
    public Lives getLives() {
        return lives;
    }

    //Method to get Hero1 with collision listener
    /**
     * The getHero1 is a getter method which adds a collision listener everytime the method is called.
     *
     * @return It returns the hero1 Object with the collision listener
     */
    public Hero1 getHero1() {
        hero1.addCollisionListener(collect);
        return hero1;
    }

    //Method to create thunders object and add a collision listener
    /**
     * The getThunder is a getter method which creates a new object everytime is called and
     * adds a collision listener.
     *
     * @return It returns the points Object with the collision listener.
     */
    public Thunder getThunder() {
        points = new Thunder(this);
        points.addCollisionListener(collect);
        return points;
    }

    //Getter method for the collect variable
    /**
     * The getCollect is a getter method which is responsible to get the collect Object.
     *
     * @return It returns the collect Object.
     */
    public Collect getCollect() {
        return collect;
    }


    //Method to create Fireballs
    /**
     * The createFireballs is a method which creates a new object fireball attaching an image on the left hand side
     * near the Hero1 with an initial velocity and a collision listener.
     *
     * @return It returns the Object fireball with a velocity, collision listener and an image attached to the left hand
     * side.
     */
    public Fireball createFireballs(){

        Fireball fireball = new Fireball(this);
        fireball.setPosition(getHero1().getPosition().add(new Vec2(-2, 0)));
        fireball.setLinearVelocity(new Vec2(-15,3));
        fireball.addCollisionListener(new Shooting(getEnemy1(),this));
        fireball.flipLeft();
        return fireball;
    }

    //Method to create Fireballs on the opposite direction
    /**
     * The createFireballsOpposite is a method which creates a new object fireball attaching an image on the Right
     * hand side near the Hero1 with an initial velocity and a collision listener.
     *
     * @return It returns the Object fireball with a velocity, collision listener and an image attached to the Right hand
     * side.
     */
    public Fireball createFireballsOpposite(){

        Fireball fireball = new Fireball(this);
        fireball.setPosition(getHero1().getPosition().add(new Vec2(2, 0)));
        fireball.setLinearVelocity(new Vec2(15,3));
        fireball.addCollisionListener(new Shooting(getEnemy1(),this));
        fireball.flipRight();

        return fireball;
    }

    //Obtains the name of the level.
    /**
     * The getLevelName is an abstract method which gets the name of the level.
     *
     * @return It returns the name of the Level the player is.
     *
     */
    public abstract String getLevelName();





}
