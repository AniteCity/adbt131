package game.Levels;
import game.Game;

import game.Levels.GameWorld;
import org.jbox2d.common.Vec2;

//Creates a class called Level2 which extends attributes from the GameWorld class
public class Level2 extends GameWorld {


    //Creating a constructor which will receive Game type variables
    public Level2(Game g) {
        super(g);



        //create a platform and set its location
        getPlat2().setPosition(new Vec2(0, -11.5f));

        //set the location of the hero
        getHero1().setPosition(new Vec2(-9   , -10));

        //loop to create multiple spikes
        for (int i = 0; i < 3; i++) {
            getSpike().setPosition(new Vec2(-6 + (i * 4.5f), -10.4f));
        }


        //Sets the location of the 2 trampolines
        getTrampoline().setPosition(new Vec2(5.5f, -10.4f));
        getTrampoline().setPosition(new Vec2(0, -4.4f));



        //Sets the location of the spike
        getSpike().setPosition(new Vec2(1.5f, 1.6f));

        //Position of the Enemy1 and adding a collision listener
        getEnemy1().setPosition(new Vec2(4, 6));
        getEnemy1().addCollisionListener(getCollect());


        //Position of the lives and adding a collision listener
        getLives().setPosition(new Vec2(8, -3));
        getLives().addCollisionListener(getCollect());

        //Position of the door and adding a collision listener
        getDoor().setPosition(new Vec2(10, 2.8f));
        getDoor().addCollisionListener(getCollect());


        //Position of the key and adding a collision listener
        getKey().setPosition(new Vec2(-9   , 0));
        getKey().addCollisionListener(getCollect());

        //Position of the Fire and adding a collision listener
        getFire().setPosition(new Vec2(-10, 5));



        //Creating multiple thunders
        for (int i = 0; i < 5; i++) {

            getThunder().setPosition(new Vec2(i * 2 - 10, i *( -5 + 10)));

        }


    }

    //This returns the string Level2 every time this method is called from the Level2.
    @Override
    public String getLevelName(){
        return "Level2";
    }
}