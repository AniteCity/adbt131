package game.Levels;
import game.Game;
import game.Levels.GameWorld;
import org.jbox2d.common.Vec2;


//Creates a class called Level3 which extends attributes from the GameWorld class
public class Level3 extends GameWorld {

    //Creating a constructor which will receive Game type variables
    public Level3(Game g) {
        super(g);


        //Spawns and sets the location of the Hero1
        getHero1().setPosition(new Vec2(10  , 11));


        //Creates the platform on the coordinates
        getPlat3().setPosition(new Vec2(0, -11.5f));

        //Spawns and sets the location of the Enemy1 and adds a collision listener
        getEnemy1().setPosition(new Vec2(3, -5));
        getEnemy1().addCollisionListener(getCollect());


        //Creates multiple Spikes
        for (int i = 0; i < 5; i++) {
            getSpike().setPosition(new Vec2(3+i, 6.5f));
        }

        for (int i = 0; i < 3; i++) {
            getSpike().setPosition(new Vec2(-7+i, 6.5f));
        }

        for (int i = 0; i < 2; i++) {
            getSpike().setPosition(new Vec2(-4.5f+i, 1f));
        }

        for (int i = 0; i < 2; i++) {
            getSpike().setPosition(new Vec2(3.5f+i, 1f));
        }

        for (int i = 0; i < 4; i++) {
            getSpike().setPosition(new Vec2(1.5f+i, -5.7f));
        }


        //Spawns spikes
        getSpike().setPosition(new Vec2(7.5f, -4.3f));

        getSpike().setPosition(new Vec2(-10.5f, -4.3f));


        //Spawns and sets the location of the Moving spikes
        getMovingSpike1().setPosition(new Vec2(-6, -10.3f));
        getMovingSpike2().setPosition(new Vec2(0f, -10.3f));
        getMovingSpike3().setPosition(new Vec2(6, -10.3f));




        //Spawns and sets the location of the Lives and adds a collision listener
        getLives().setPosition(new Vec2(8, 5));
        getLives().addCollisionListener(getCollect());


        //Spawns and sets the location of the Door and adds a collision listener
        getDoor().setPosition(new Vec2(11, -9.3f));
        getDoor().addCollisionListener(getCollect());

        //Spawns and sets the location of the Key and adds a collision listener
        getKey().setPosition(new Vec2(11   , 0));
        getKey().addCollisionListener(getCollect());


        //Spawns and sets the location of the Fire and adds a collision listener
        getFire().setPosition(new Vec2(-10, 7));


        //Creates multiple thunders
        for (int i = 0; i < 2; i++) {

            getThunder().setPosition(new Vec2(i * 8f - 2, i * -4 + 8));

        }


    }
    //This returns the string Level3 every time this method is called from the Level3.
    @Override
    public String getLevelName(){
        return "Level3";
    }
}
