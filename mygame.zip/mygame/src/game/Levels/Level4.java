package game.Levels;
import game.Game;

import game.Levels.GameWorld;
import org.jbox2d.common.Vec2;

//Creates a class called Level4 which extends attributes from the GameWorld class
public class Level4 extends GameWorld {


    //Creating a constructor which will receive Game type variables
    public Level4(Game g) {
        super(g);


        //Spawns and sets the location of the Hero1
        getHero1().setPosition(new Vec2(10  , -11));

        //Spawns and sets the location of the platform
        getPlat4().setPosition(new Vec2(0, -11.5f));


        //Spawns and sets the location of the Enemy1
        getEnemy1().setPosition(new Vec2(-6, 2.5f));
        getEnemy1().addCollisionListener(getCollect());

        //Spawns and sets the location of the Lives and adds a collision listener
        getLives().setPosition(new Vec2(-11, 5));
        getLives().addCollisionListener(getCollect());

        //Spawns and sets the location of the Door and adds a collision listener
        getDoor().setPosition(new Vec2(-11, -9.3f));
        getDoor().addCollisionListener(getCollect());

        //Spawns and sets the location of the key and adds a collision listener
        getKey().setPosition(new Vec2(-11   , 11));
        getKey().addCollisionListener(getCollect());


        //Spawns and sets the location of the Fire
        getFire().setPosition(new Vec2(-11, -1));
        getFire().setPosition(new Vec2(11, -4));
        getEnemy2().setPosition(new Vec2(-5, -4.3f));

        //Spawns and sets the location of the Trampoline
        getTrampoline().setPosition(new Vec2(-1, -10.3f));
        getTrampoline().setPosition(new Vec2(4, -4.3f));
        getTrampoline().setPosition(new Vec2(9.5f, 1.8f));

        //Spawns and sets the location of the Spikes
        getSpike().setPosition(new Vec2(-2.5f, -4.4f));
        getSpike().setPosition(new Vec2(-9.5f, -4.4f));

        getSpike().setPosition(new Vec2(-9.5f, 1.6f));
        getSpike().setPosition(new Vec2(-2.5f, 1.6f));

        getSpike().setPosition(new Vec2(-9.5f, 7.6f));

        //Spawns and sets the location of the Moving Spikes
        getMovingSpike1().setPosition(new Vec2(-6.5f, 10.6f));
        getMovingSpike2().setPosition(new Vec2(-6.5f, 10.6f));
        getMovingSpike3().setPosition(new Vec2(-6.5f, 10.6f));

        //Creates multiple thunders
        for (int i = 0; i < 3; i++) {

            getThunder().setPosition(new Vec2(i * 4 - 3, i * -5 + 10));

        }


    }

    //This returns the string Level4 every time this method is called from the Level4.

    @Override
    public String getLevelName(){
        return "Level4";
    }
}
