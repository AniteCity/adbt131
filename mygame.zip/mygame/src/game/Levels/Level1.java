package game.Levels;
import game.Game;
import game.Levels.GameWorld;
import org.jbox2d.common.Vec2;


//Creates a class called Level1 which extends attributes from the GameWorld class
public class Level1 extends GameWorld {



    //Creating a constructor which will receive Game type variables
    public Level1(Game g) {
        super(g);

        //Creates the platform on the coordinates
        getPlat1().setPosition(new Vec2(0, -11.5f));

        //Spawns the hero1
        getHero1().setPosition(new Vec2(8, -10));

        //Sets the location of the door and adds a collision listener
        getDoor().setPosition(new Vec2(-11, 3.3f));
        getDoor().addCollisionListener(getCollect());

        //sets the location of the enemy1
        getEnemy1().setPosition(new Vec2(-5, 3));


        //spawns the spikes
        spawnSpikes();



        //Sets the location of the spikes and adds a collision listener
        getLives().setPosition(new Vec2(8, 5));
        getLives().addCollisionListener(getCollect());

        //Sets the location of the key and adds a collision listener
        getKey().setPosition(new Vec2(-10, -2));
        getKey().addCollisionListener(getCollect());

        //Sets the location of the fire and adds a collision listener
        getFire().setPosition(new Vec2(5, 8));





        //Loop to create multiple thunders
        for (int i = 0; i < 3; i++) {


            getThunder().setPosition(new Vec2(i+2.3f , i * -8 + 10));

        }









    }

 //Method to create all the spikes
public void spawnSpikes(){


    for (int i = 0; i < 2; i++) {

        getSpike().setPosition(new Vec2(-0.2f + i, 1));

    }


    for (int i = 0; i < 4; i++){
        getSpike().setPosition(new Vec2(3.1f + i, -4.5f));
    }


    getSpike().setPosition(new Vec2(-1.5f , 2.2f));



    getSpike().setPosition(new Vec2(-3.7f , -7f));


    getSpike().setPosition(new Vec2(0.8f , -5f));


}

    //This returns the string Level1 everytime this method is called from the Level1.
    @Override
    public String getLevelName(){
            return "Level1";
    }

}



