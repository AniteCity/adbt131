package game.Collectable;
import city.cs.engine.*;

//Creates a class called Thunder which extends attributes from the Walker class
public class Thunder extends Walker {

    //Creates a constructor which will receive a variable of type World
    public Thunder(World world) {
        super(world, thunder);//It calls a constructor from the Walker class and attaches the thunder shape to the world
        addImage(image);//Attaches an image which is stored in the image variable
    }



    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape thunder = new PolygonShape(0.607f,0.738f, -0.098f,-0.75f,
            -0.599f,-0.741f, -0.461f,0.741f);


    private static final BodyImage image = new BodyImage("data/thunder.png", 1.5f);
}
