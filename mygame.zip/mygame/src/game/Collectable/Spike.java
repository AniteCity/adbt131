package game.Collectable;

import city.cs.engine.*;



//Creates a class called Spike which extends attributes from the StaticBody class
public class Spike extends StaticBody {

    //Creates a constructor which will receive a variable of type World
    public Spike(World world) {
        super(world, spike);//It calls a constructor from the Walker class and attaches the spike shape to the world
        addImage(image);//Attaches an image which is stored in the image variable
    }



    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape spike = new PolygonShape(-0.04f,0.595f, 0.437f,-0.595f, -0.434f,-0.595f, -0.434f,-0.456f);


    private static final BodyImage image = new BodyImage("data/spike.png", 1.2f);
}
