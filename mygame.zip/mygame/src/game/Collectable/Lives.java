package game.Collectable;
import city.cs.engine.*;
import city.cs.engine.Shape;

//Creates a class called Lives which extends attributes from the Walker class
public class Lives extends Walker {


    //Creates a constructor which will receive a variable of type World
    public Lives(World world) {
        super(world,heart);//It calls a constructor from the Walker class and attaches the heart shape to the world
        addImage(life);//Attaches an image which is stored in the life variable

    }

    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape heart = new PolygonShape(-0.57f,0.48f, -0.56f,-0.55f, 0.55f,-0.55f, 0.57f,0.55f, -0.55f,0.52f);


    private static final BodyImage life = new BodyImage("data/live.png", 3.5f);




}
