package game.Collectable;

import city.cs.engine.*;


//Creates a class called Key which extends attributes from the Walker class

public class Key extends Walker {

    //Declaring variable for check boolean
    private Boolean check;

    //Creates a constructor which will receive a variable of type World
    public Key(World world) {

        super(world, key);//It calls a constructor from the Walker class and attaches the key shape to the world
        addImage(image);//Attaches an image which is stored in the image variable
        check=false; //Instantiates the check variable
    }

    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape key = new PolygonShape(-0.447f,0.594f, 0.648f,0.57f, 0.594f,-0.525f, -0.492f,-0.531f);


    private static final BodyImage image = new BodyImage("data/key.png", 1.5f);


    //Creates setter method to set the the value of the key to true
    public boolean keyCheck() {

        check = true;
        System.out.println("Key Collected!");

        return check;
    }

    //Getter method to get the value of the check variable
    public Boolean getCheck() {
        return check;
    }
}
