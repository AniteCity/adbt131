package game.Collectable;

import city.cs.engine.*;




//Creates a class called Door which extends attributes from the StaticBody class
public class Door extends StaticBody {

    //Creates a constructor which will receive a variable of type World
    public Door(World w) {

        //It calls a constructor from the Walker class and attaches the fireball shape to the world
        super(w,door);

        //Attaches an image which is stored in the image/image1 variable
        addImage(image);

    }







    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape door = new PolygonShape(
            1.02f,1.75f, 1.03f,-1.74f, -1.0f,-1.74f, -1.03f,1.73f);

    private static final BodyImage image = new BodyImage("data/staticdoor.png", 3.5f);
    private static final BodyImage image1 = new BodyImage("data/door1.gif", 3.5f);


    //Changes adds a moving image to the door
    public void moveDoor() {

        addImage(image1);

    }

}
