package game.Collectable;

import city.cs.engine.*;



//Creates a class called MovingSpike which extends attributes from the Walker class
public class MovingSpike extends Walker {

    //Creates a constructor which will receive a variable of type World
    public MovingSpike(World world) {
        super(world, movingSpike);//It calls a constructor from the Walker class and attaches the movingSpike shape to the world
        addImage(image);//Attaches an image which is stored in the image variable

    }



   /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape movingSpike = new PolygonShape(-0.436f,0.593f, -0.002f,-0.598f, 0.444f,0.607f);


    private static final BodyImage image = new BodyImage("data/movingSpike.png", 1.2f);



}
