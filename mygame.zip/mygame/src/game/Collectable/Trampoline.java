package game.Collectable;

import city.cs.engine.*;


//Creates a class called Trampoline which extends attributes from the StaticBody class
public class Trampoline extends StaticBody {

    //Creates a constructor which will receive a variable of type World
    public Trampoline(World w) {

        //It calls a constructor from the Walker class and attaches the trampoline shape to the world
        super(w,trampoline);

        //Attaches an image which is stored in the image variable
        addImage(image);

    }

    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape trampoline = new PolygonShape(
            1.752f,-0.755f, 1.752f,0.743f, -1.766f,0.743f, -1.752f,-0.727f);


    private static final BodyImage image = new BodyImage("data/trampoline.png", 1.5f);


}

