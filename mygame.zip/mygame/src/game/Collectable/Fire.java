package game.Collectable;

import city.cs.engine.*;


//Creates a class called Fire which extends attributes from the Walker class

public class Fire extends Walker {

    //Declaring variable for fire count
    private int fireCount;

    //Creates a constructor which will receive a variable of type World
    public Fire(World world) {
        super(world, fire);//It calls a constructor from the Walker class and attaches the fire shape to the world
        addImage(image);//Attaches an image which is stored in the image variable
        fireCount=0;//Instantiates the variable fireCount
    }



    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape fire = new PolygonShape(-0.832f,-0.758f, 0.772f,-0.738f, 0.842f,0.743f, -0.832f,0.75f);


    private static final BodyImage image = new BodyImage("data/fire.gif", 1.5f);



    //Creating methods to increment the fireCount variable
    public void incrementFireCount() {
        fireCount++;
        System.out.println("No of Fire Collected: " + fireCount);
    }

    //Creating methods to decrement the fireCount variable
    public void decrementFireCount() {
        fireCount--;
        System.out.println("No of Fire Remaining: " + fireCount);
    }


    //Creating getter methods for the fireCount variable
    public int getFireCount() {
        return fireCount;
    }



}
