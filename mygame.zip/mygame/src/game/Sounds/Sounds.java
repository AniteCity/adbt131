package game.Sounds;

import city.cs.engine.SoundClip;
import city.cs.engine.World;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

//Class for all the sounds of the game
public class Sounds {

    //Declaring Variables
    private static SoundClip collectThunder;
    private static SoundClip addlive;
    private static SoundClip takeLive;
    private static SoundClip key;
    private static SoundClip fireball;
    private static SoundClip shooting;
    private static SoundClip jump;



    /*Creating all the sound objects related to the game*/

    //Thunder
    static {
        try {
            collectThunder = new SoundClip("data/collectThunder.wav");
            collectThunder.setVolume(2);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }

    //AddLive
    static {
        try {
            addlive = new SoundClip("data/addlive.wav");
            addlive.setVolume(2);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }

    //TakeLive
    static {
        try {
            takeLive = new SoundClip("data/takelive.wav");
            takeLive.setVolume(2);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }


    //Key
    static {
        try {
            key = new SoundClip("data/key.wav");
            key.setVolume(2);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }

    //Shooting
    static {
        try {
            shooting = new SoundClip("data/shooting.wav");
            shooting.setVolume(2);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }

    //Fireball
    static {
        try {
            fireball = new SoundClip("data/fireball.wav");
            fireball.setVolume(2);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }

    //Jump
    static {
        try {
            jump = new SoundClip("data/jump.wav");
            jump.setVolume(0.5);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }


/*Methods to stop and play each sound of the game*/

    public void stopKeySound(){

        key.stop();
    }




    public void stopTakeLiveSound(){

        takeLive.stop();
    }


    public void stopAddLiveSound(){

        addlive.stop();
    }



    public void stopThunderSound(){

        collectThunder.stop();
    }






    public void stopFireballSound(){

        fireball.stop();
    }




    public void stopShootingSound(){

        shooting.stop();
    }


    public void stopJumpSound(){

        jump.stop();
    }


    public void playJumpSound(){

        jump.play();
    }
    public void playShootingSound(){

        shooting.play();
    }




    public void playFireballSound(){

        fireball.play();
    }
    public void playKeySound(){

        key.play();
    }




    public void playTakeLiveSound(){

        takeLive.play();
    }


    public void playAddLiveSound(){

        addlive.play();
    }



    public void playThunderSound(){

        collectThunder.play();
    }

    public void stopAllSounds(){

        collectThunder.stop();
        jump.stop();
        shooting.stop();
        fireball.stop();
        addlive.stop();
        takeLive.stop();

        key.stop();


    }

    public void playAllSounds(){

        collectThunder.play();
        jump.play();
        shooting.play();
        fireball.play();
        addlive.play();
        takeLive.play();

        key.play();


    }

}
