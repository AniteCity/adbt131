package game.Collect;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import city.cs.engine.StaticBody;
import game.Collectable.*;
import game.Controls.Keyboard;
import game.Game;
import game.GameCharacters.Enemy1;
import game.GameCharacters.Enemy2;
import game.GameCharacters.Hero1;
import game.Levels.GameWorld;
import game.Sounds.Sounds;

import javax.swing.*;
import java.awt.*;

//Creates a class called collect which inherits the properties of the interface CollisionListener
public class Collect implements CollisionListener {

    //Declaring all the variables
    private Hero1 hero1;
    private Game game;
    private Key key;
    private Door door;
    private GameWorld level;
    private float speed=5;
    private float jumpSpeed=5.8f;
    private Sounds sounds;
    private Keyboard keyboard;


    /*Creating a constructor to import the Hero1, Game, Key, Door, GameWorld, Sound and Keyboard
    attributes to this class */
    public Collect(Hero1 hero, Game w, Key k, Door d,GameWorld g,Sounds s,Keyboard keyboard) {
        this.hero1 = hero;
        this.game = w;
        this.key = k;
        this.door = d;
        this.level = g;
        this.sounds = s;
        this.keyboard = keyboard;
    }

    //This overrides the "collide" method
    @Override
    public void collide(CollisionEvent collision) {

        /* Checks if the reporting body which is the body being hit detected
        any collision with another type of body called Hero1  */

        if(collision.getReportingBody() instanceof Thunder && collision.getOtherBody() == hero1){

            //Checks if the tick box is ticked or not so it decide to play or mute the sound
            //0 = Sound On(not ticked) and 1 = Sound Off (ticked)
            if (level.getButtons().getTickbox() == 0) {

                this.sounds.playThunderSound();

            } else if (level.getButtons().getTickbox() == 1) {

                this.sounds.stopThunderSound();
            }

            //Calls a method to increment the thunder counter
            hero1.incrementThunderCount();

            //Sets the Jump Speed of the player back to normal speed
            keyboard.setJumpspeed(jumpSpeed);

            //It destroys the reporting body
            collision.getReportingBody().destroy();


        }else if(collision.getReportingBody() instanceof Enemy1 && collision.getOtherBody() == hero1){

            //Checks if the tick box is ticked or not so it decide to play or mute the sound
            //0 = Sound On(not ticked) and 1 = Sound Off (ticked)
            if (level.getButtons().getTickbox() == 0) {

                this.sounds.playTakeLiveSound();

            } else if (level.getButtons().getTickbox() == 1) {

                this.sounds.stopTakeLiveSound();
            }


            //Calls a method to decrement the counter of lives.
            hero1.decrementLivesCount();

            //Sets the Jump Speed of the player back to normal speed
            keyboard.setJumpspeed(jumpSpeed);




            /*Checks if the No of Lives is equal to 2, if Yes then it set the array to only have
             2 hearts, if the No of Lives is equal to 1 then it will set the array to only have
             1 heart and if No of Lives equal 0 then the array will be empty displaying no hearts
             and it will destroy the Hero1*/

            if (level.getHero1().getLivesCount() == 3) {

                game.getView().set3Lives();

            } else if (level.getHero1().getLivesCount() == 2) {

                game.getView().set2Lives();

            } else if (level.getHero1().getLivesCount() == 1) {

                game.getView().set1Lives();

            }  else if (level.getHero1().getLivesCount() == 0) {

                game.getView().set0Lives();
                collision.getOtherBody().destroy();

            }

        }else if(collision.getReportingBody() instanceof Enemy2 && collision.getOtherBody() == hero1){





            //Checks if the tick box is ticked or not so it decide to play or mute the sound
            //0 = Sound On(not ticked) and 1 = Sound Off (ticked)
            if (level.getButtons().getTickbox() == 0) {

                this.sounds.playTakeLiveSound();

            } else if (level.getButtons().getTickbox() == 1) {

                this.sounds.stopTakeLiveSound();
            }




            //Sets the Jump Speed of the player back to normal speed
            keyboard.setJumpspeed(jumpSpeed);

            //Calls a method to decrement the counter of lives.
            hero1.decrementLivesCount();


            /*Checks if the No of Lives is equal to 2, if Yes then it set the array to only have
             2 hearts, if the No of Lives is equal to 1 then it will set the array to only have
             1 heart and if No of Lives equal 0 then the array will be empty displaying no hearts
             and it will destroy the Hero1*/

            if (level.getHero1().getLivesCount() == 3) {

                game.getView().set3Lives();

            } else if (level.getHero1().getLivesCount() == 2) {

                game.getView().set2Lives();

            } else if (level.getHero1().getLivesCount() == 1) {

                game.getView().set1Lives();

            }  else if (level.getHero1().getLivesCount() == 0) {

                game.getView().set0Lives();
                collision.getOtherBody().destroy();

            }

        }else if(collision.getReportingBody() instanceof Lives && collision.getOtherBody() == hero1){

            //Checks if the tick box is ticked or not so it decide to play or mute the sound
            //0 = Sound On(not ticked) and 1 = Sound Off (ticked)
            if (level.getButtons().getTickbox() == 0) {

                this.sounds.playAddLiveSound();

            } else if (level.getButtons().getTickbox() == 1) {

                this.sounds.stopAddLiveSound();
            }

            /*Depending on the No of lives only certain Hearts will be displayed on the screen*/
            if (level.getHero1().getLivesCount() == 2) {

                game.getView().set3Lives();

            } else if (level.getHero1().getLivesCount() == 1) {

                game.getView().set2Lives();

            } else if (level.getHero1().getLivesCount() == 0) {

                game.getView().set1Lives();

            }

            //Sets the Jump Speed of the player back to normal speed
            keyboard.setJumpspeed(jumpSpeed);

            /*Checks if Hero1's lives are less than or equal to 2 than it will add one live if the Hero1 picks up
             a life, otherwise if the life counter is at 3 and if the hero1 picks up a life then it will say the life
             is full*/
            if (hero1.getLivesCount() <= 2) {

                hero1.incrementLivesCount();
                collision.getReportingBody().destroy();


            } else {

                collision.getReportingBody().destroy();//destroys the life pickup object
                System.out.println("Your life is full!");
            }

        }else if(collision.getReportingBody() instanceof Key && collision.getOtherBody() == hero1) {

            //Checks if the tick box is ticked or not so it decide to play or mute the sound
            //0 = Sound On(not ticked) and 1 = Sound Off (ticked)
            if (level.getButtons().getTickbox() == 0) {

                this.sounds.playKeySound();

            } else if (level.getButtons().getTickbox() == 1) {

                this.sounds.stopKeySound();
            }


            collision.getReportingBody().destroy();//Destroys the Key

            //Sets an image of the key once collected
            game.getView().setKey(new ImageIcon("data/paintKey.png").getImage());

            //Calls the keyCheck method to check if the key was picked or not
            key.keyCheck();

            //The animation of the door will start to play
            door.moveDoor();

            //Sets the Jump Speed of the player back to normal speed
            keyboard.setJumpspeed(jumpSpeed);

        }else if(collision.getReportingBody() instanceof Door && collision.getOtherBody() == hero1) {

            /*Once collided with the Door it will check if the Key was picked, if yes it will call
              the goTONextLevel method to change the level. If the key wasn't picked then
              it will say that the door is locked*/

            if (key.getCheck() == true) {

                this.game.goToNextLevel(true);

            } else {
                System.out.println("Door locked");
            }


            //Sets the Jump Speed of the player back to normal speed
            keyboard.setJumpspeed(jumpSpeed);

        }else if(collision.getReportingBody() instanceof Fire && collision.getOtherBody() == hero1) {

            //Checks if the tick box is ticked or not so it decide to play or mute the sound
            //0 = Sound On(not ticked) and 1 = Sound Off (ticked)

            if (level.getButtons().getTickbox() == 0) {

                this.sounds.playFireballSound();

            } else if (level.getButtons().getTickbox() == 1) {

                this.sounds.stopFireballSound();
            }

            //Displays the Fire Icon on the Screen
            game.getView().setFlameIcon();

            //Destroys the Fire object
            collision.getReportingBody().destroy();

            //Calls a method to increase the fireCount value
            this.level.increaseFireCount();

            //Sets the Jump Speed of the player back to normal speed
            keyboard.setJumpspeed(jumpSpeed);



        }else if(collision.getReportingBody() instanceof Spike && collision.getOtherBody() == hero1) {

            //Checks if the tick box is ticked or not so it decide to play or mute the sound
            //0 = Sound On(not ticked) and 1 = Sound Off (ticked)
            if (level.getButtons().getTickbox() == 0) {

                this.sounds.playTakeLiveSound();

            } else if (level.getButtons().getTickbox() == 1) {

                this.sounds.stopTakeLiveSound();
            }


            //Calls a method to decrement the value of the Lives
            hero1.decrementLivesCount();



            /*Checks if the No of Lives is equal to 2, if Yes then it set the array to only have
             2 hearts, if the No of Lives is equal to 1 then it will set the array to only have
             1 heart and if No of Lives equal 0 then the array will be empty displaying no hearts
             and it will destroy the Hero1*/

            if (level.getHero1().getLivesCount() == 2) {

                game.getView().set2Lives();

            } else if (level.getHero1().getLivesCount() == 1) {

                game.getView().set1Lives();

            } else if (level.getHero1().getLivesCount() == 0) {

                game.getView().set0Lives();
                collision.getOtherBody().destroy();

            }

            keyboard.setJumpspeed(jumpSpeed);


        }else if(collision.getReportingBody() instanceof Door && collision.getOtherBody() instanceof Enemy1) {

            /* If the Enemy1 body collides with the Door it will invert its direction */
            if (speed > 0) {
                speed = -speed;
                level.setEnemy1Speed(speed);
                level.getEnemy1().removeAllImages();
                level.getEnemy1().flipLeft();

            } else if (speed < 0) {
                speed = speed + 10;
                level.setEnemy1Speed(speed);
                level.getEnemy1().removeAllImages();
                level.getEnemy1().flipLeft();

            }


        }else if(collision.getReportingBody() instanceof Spike && collision.getOtherBody() instanceof Enemy1) {

            /* If the Enemy1 body collides with the spike it will invert its direction */
            if (speed < 0) {
                speed = speed + 10;
                level.setEnemy1Speed(speed);
                level.getEnemy1().removeAllImages();
                level.getEnemy1().flipLeft();



            } else {
                speed = -speed;
                level.setEnemy1Speed(speed);
                level.getEnemy1().removeAllImages();
                level.getEnemy1().flipLeft();


            }

        }else if (collision.getReportingBody() instanceof Trampoline && collision.getOtherBody() instanceof Hero1) {

            //If the player hits the trampoline, the jumping speed of the player will change
            keyboard.setJumpspeed(10);


        } else if (collision.getReportingBody() instanceof Hero1 && collision.getOtherBody() instanceof StaticBody) {

            //If the player collides with any static body the speed will be set back to normal
            keyboard.setJumpspeed(jumpSpeed);


        } else if (collision.getReportingBody() instanceof MovingSpike && collision.getOtherBody() instanceof Hero1) {

            //Checks if the tick box is ticked or not so it decide to play or mute the sound
            //0 = Sound On(not ticked) and 1 = Sound Off (ticked)

            if (level.getButtons().getTickbox() == 0) {

                this.sounds.playTakeLiveSound();

            } else if (level.getButtons().getTickbox() == 1) {

                this.sounds.stopTakeLiveSound();
            }

            //Decrements the life variable
            hero1.decrementLivesCount();



            /*Checks if the No of Lives is equal to 2, if Yes then it set the array to only have
             2 hearts, if the No of Lives is equal to 1 then it will set the array to only have
             1 heart and if No of Lives equal 0 then the array will be empty displaying no hearts
             and it will destroy the Hero1*/

            if (level.getHero1().getLivesCount() == 2) {

                game.getView().set2Lives();

            } else if (level.getHero1().getLivesCount() == 1) {

                game.getView().set1Lives();

            } else if (level.getHero1().getLivesCount() == 0) {

                game.getView().set0Lives();
                collision.getOtherBody().destroy();

            }

            //Destroys the MovingSpike
            collision.getReportingBody().destroy();

            //Set the speed of the player back to normal speed
            keyboard.setJumpspeed(jumpSpeed);

        } else if (collision.getReportingBody() instanceof Spike && collision.getOtherBody() instanceof Enemy2) {

            /*Everytime Enemy2 collides with the spike its direction will be inverted*/

            if (level.getEnemy2Speed() > 0) {

                level.setEnemy2Speed(-(level.getEnemy2Speed()));
                level.setEnemy2Walking(level.getEnemy2Speed());
                level.getOnlyEnemy2().removeAllImages();
                level.getEnemy2RImage();


            } else if (level.getEnemy2Speed() < 0) {

                level.setEnemy2Speed(level.getEnemy2Speed() + 10);
                level.setEnemy2Walking(level.getEnemy2Speed());
                level.getOnlyEnemy2().removeAllImages();
                level.getEnemy2LImage();


            }


        } else if (collision.getReportingBody() instanceof MovingSpike && collision.getOtherBody() instanceof StaticBody) {


                //Call a method to set a linear velocity vertically
                level.getMovingSpikeUp();





        }

    }

}
