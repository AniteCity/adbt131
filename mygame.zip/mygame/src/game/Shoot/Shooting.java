package game.Shoot;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import city.cs.engine.StaticBody;
import game.Ammos.Fireball;
import game.Collectable.Lives;
import game.Collectable.Thunder;
import game.GUI.ControlPanel;
import game.GameCharacters.Enemy1;
import game.GameCharacters.Enemy2;
import game.Levels.GameWorld;

/**
 * This class is responsible to create a new GameView to add additional properties on the screen
 * such as the player's score, health and score.
 *
 * @author Anite Cangi
 * @version 1.0
 * @see GameWorld
 * @see ControlPanel
 */

//Creates a class called Shooting which inherits the properties of the interface CollisionListener
public class Shooting implements CollisionListener {

    //Declaring variables
    private Enemy1 enemy1;
    private GameWorld level;

    /*Creating a constructor to import the Enemy1 and GameWorld attributes to this class */

    /**
     * The Shooting is a constructor which is responsible to obtain properties from other classes to use in the Shooting
     * class.
     *
     * @param enemy1 It receives a variable of type Enemy1
     * @param g It receives a variable of type GameWorld
     */
    public Shooting(Enemy1 enemy1,GameWorld g){

        this.enemy1=enemy1;
        this.level=g;
    }


    //This overrides the "collide" method

    /**
     * The Collide method is overridden which is responsible for checking if The Fireball collides with any sort
     * of material other than the enemy.
     *
     * @param collisionEvent It receives a variable type of CollisionEvent.
     */
    @Override
    public void collide(CollisionEvent collisionEvent) {

        //If the Fireball collides with any body that is static, a life or a thunder it should destroy it self
        /**
         * This checks if Fireball collides with a static body,thunder or Lives object.
         */
        if(collisionEvent.getReportingBody() instanceof Fireball && collisionEvent.getOtherBody() instanceof StaticBody ||
                collisionEvent.getOtherBody() instanceof Lives ||  collisionEvent.getOtherBody() instanceof Thunder){

            //Destroy the fireball
            /**
             * This method is called to destroy reporting body which is the Fireball
             */
            collisionEvent.getReportingBody().destroy();


            /**
             * This if statement checks if the Fireball collides with he enemy1
             */
        }else if (collisionEvent.getReportingBody() instanceof Fireball && collisionEvent.getOtherBody() instanceof Enemy1){

            //Destroy the Fireball
            /**
             * Once it collides with the enemy1 the fireball will be destroyed.
             */
            collisionEvent.getReportingBody().destroy();
            System.out.println("hit");


            //Decrease enemy1 life
            /**
             * Decrease the enemy1 life.
             */
            this.level.getEnemy1().decrementEnemy1Life();


            //if enemy1 life 0 then it will be destroyed
            /**
             * Checks if the enemy1's life is 0 then destroy the object
             */
            if(this.level.getEnemy1().getEnemy1Life()==0)
            {
                System.out.println("Decreased");
                /**
                 * Calls a method to destroy the enemy1
                 */
                collisionEvent.getOtherBody().destroy();



            }



        /**
         * This if statement checks if the Fireball collides with he enemy2
         */
        }else if (collisionEvent.getReportingBody()  instanceof Fireball && collisionEvent.getOtherBody() instanceof Enemy2){

            //Destroy fireball
            /**
             * Once it collides with the enemy2 the fireball will be destroyed.
             */
            collisionEvent.getReportingBody().destroy();

            //Decrease Enemy2 life count
            /**
             * Decrease the enemy2 life.
             */
            this.level.decreaseEnemy2LifeCount();

            //If enemy2 life count is 0 then it will destroy the enemy2
            /**
             * Checks if the enemy2's life is 0 then destroy the object
             */
            if(this.level.getOnlyEnemy2().getEnemy2Life()==0)
            {
                System.out.println("Decreased");
                /**
                 * Calls a method to destroy the enemy2
                 */
                collisionEvent.getOtherBody().destroy();



            }





        }


    }
}
