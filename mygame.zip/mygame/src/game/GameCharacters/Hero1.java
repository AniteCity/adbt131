package game.GameCharacters;

import city.cs.engine.*;


//Creates a class called Hero1 which extends attributes from the Walker class
public class Hero1 extends Walker{

    //Creates variable to count lives and thunders
    private int thunderCount;
    private int livesCount;

    //Creates a constructor which will receive a variable of type World
    public Hero1(World world1) {

        /*It calls a constructor from the Walker class and attaches the hero1 shape to the world1*/
        super(world1,hero1);
        addImage(image);//Attaches an image which is stored in the image variable
        thunderCount=0;//Initialises the thunderCount to 0
        livesCount=3;//Initialises the livesCount to 3


    }

    //Creating setter method to increase thunders.
    public void incrementThunderCount() {
        thunderCount++;
        System.out.println("No of Thunder Collected: " + thunderCount);
    }

    //Getter method to get the No of Thunders
    public int getThunderCount() {
        return thunderCount;
    }

    //Creating setter method to decrease the No of lives.
    public void decrementLivesCount() {
        livesCount--;
        System.out.println("Lost a life! Remaining: " + livesCount);
    }

    //Getter method to get the No of lives
    public int getLivesCount() {
        return livesCount;
    }


    //Creating setter method to increase the No of lives.
    public void incrementLivesCount() {
        livesCount++;
        System.out.println("Gain  a life!! Remaining: " + livesCount);

    }

    //Creating a method to attach the an image to the Hero1 and flip it Horizontally
    public void flipLeft() {
        addImage(image).flipHorizontal();

    }
    //Creating a method which sets image of the Hero1 back to normal direction
    public void flipRight() {
        addImage(image);

    }

    //Setter method to set the value of thunderCount variable
    public void setThunderCount(int thunderCount) {
        this.thunderCount = thunderCount;
    }

    //Setter method to set the value of livesCount variable
    public void setLivesCount(int livesCount) {
        this.livesCount = livesCount;
    }
/*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape hero1 = new PolygonShape(
            -0.88f,1.21f, 0.29f,1.38f, 0.65f,0.9f, 0.62f,-1.67f, -0.73f,-1.67f, -0.89f,1.14f);

    private static final BodyImage image = new BodyImage("data/hero1.png", 3.5f);


}
