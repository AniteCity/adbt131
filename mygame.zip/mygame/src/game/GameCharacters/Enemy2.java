package game.GameCharacters;

import city.cs.engine.*;


//Creates a class called Enemy2 which extends attributes from the Walker class
public class Enemy2 extends Walker {

    //Declaring a variable
    int enemyLife;

    //Creates a constructor which will receive a variable of type World
    public Enemy2(World world) {
        /*It calls a constructor from the Walker class and attaches the enemy2 shape to the world*/
        super(world, enemy2);
        addImage(image);//Attaches an image which is stored in the image variable
        enemyLife=1;//Instantiates the enemyLife variable
    }


    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor to set the path of the image and the height*/

    private static final Shape enemy2 = new PolygonShape(-1.9f,1.92f, -1.9f,-1.91f, 1.9f,-1.88f, 1.82f,1.88f);

    private static final BodyImage image = new BodyImage("data/zombieL.gif", 3.8f);



    //Creating a method to decrement the life of the enemy2
    public void decrementEnemy2Life() {
        enemyLife--;
        System.out.println("Enemy life: " + enemyLife);
    }

    //Getter method for the Enemy2Life variable
    public int getEnemy2Life() {
        return enemyLife;
    }


    //Method to flip the image horizontally
    public void flipLeft() {
        addImage(image).flipHorizontal();

    }

    //Method to attach the image on the correct direction
    public void flipRight() {
        addImage(image);

    }
}
