package game.GameCharacters;

import city.cs.engine.*;

//Creates a class called Enemy1 which extends attributes from the Walker class
public class Enemy1 extends Walker {


    //Declaring a variable
    private int enemyLife;

    //Creates a constructor which will receive a variable of type World
    public Enemy1(World world) {

        /*It calls a constructor from the Walker class and attaches the enemy1 shape to the world*/
        super(world, enemy1);
        addImage(image);//Attaches an image which is stored in the image variable
        enemyLife=1;
    }


    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor to set the path of the image and the height*/

    private static final Shape enemy1 = new PolygonShape(-2.86f,1.0f, -2.86f,-0.991f, 2.871f,-0.991f, 2.871f,1.023f);

    private static final BodyImage image = new BodyImage("data/enemy1.png", 2.0f);



    //Method to decrement the value of the enemyLife variable
    public void decrementEnemy1Life() {
        enemyLife--;
        System.out.println("Enemy life: " + enemyLife);
    }

    //Getter method for the enemyLife variable
    public int getEnemy1Life() {
        return enemyLife;
    }


    //Method to flip the image horizontally
    public void flipLeft() {
        addImage(image).flipHorizontal();

    }


}
