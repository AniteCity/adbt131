package game.Construnction;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import city.cs.engine.World;
import org.jbox2d.common.Vec2;

import java.awt.*;

//Creates a class called Platform_Level3 which extends attributes from the StaticBody class
public class Platform_Level3 extends StaticBody {

    //Creates a constructor which will receive a variable of type World
    public Platform_Level3(World w) {

        super(w,plat3);//It calls a constructor from the StaticBody class and attaches the world with the platform shape
        setFillColor(Color.cyan.darker());//sets the color of the platform

        /*Creates a variable with the Shape Object type and instantiates with the "new" keyword
        and initialises by called the BoxShape constructor and creates another object of type Static body.
        Also applies a color to the platforms.*/
        Shape thirdFloor3 = new BoxShape(2, 0.5f);
        StaticBody Tfloor3= new StaticBody(w, thirdFloor3);
        Tfloor3.setPosition(new Vec2(10, 6.5f));
        Tfloor3.setFillColor(Color.cyan.darker());

        Shape thirdFloor2 = new BoxShape(1f, 0.5f);
        StaticBody Tfloor2= new StaticBody(w, thirdFloor2);
        Tfloor2.setPosition(new Vec2(1, 6.5f));
        Tfloor2.setFillColor(Color.cyan.darker());

        Shape thirdFloor1 = new BoxShape(1f, 0.5f);
        StaticBody Tfloor1= new StaticBody(w, thirdFloor1);
        Tfloor1.setPosition(new Vec2(-3.2f, 6.5f));
        Tfloor1.setFillColor(Color.cyan.darker());

        Shape thirdFloor0 = new BoxShape(2f, 0.5f);
        StaticBody Tfloor0= new StaticBody(w, thirdFloor0);
        Tfloor0.setPosition(new Vec2(-10f, 6.5f));
        Tfloor0.setFillColor(Color.cyan.darker());


        Shape secondFloor0 = new BoxShape(0.5f, 0.5f);
        StaticBody Sfloor0= new StaticBody(w, secondFloor0);
        Sfloor0.setPosition(new Vec2(-11.5f, 0.5f));
        Sfloor0.setFillColor(Color.cyan.darker());

        Shape secondFloor1 = new BoxShape(2f, 0.5f);
        StaticBody Sfloor1= new StaticBody(w, secondFloor1);
        Sfloor1.setPosition(new Vec2(-7f, 0.5f));
        Sfloor1.setFillColor(Color.cyan.darker());


        Shape secondFloor3 = new BoxShape(3f, 0.5f);
        StaticBody Sfloor3= new StaticBody(w, secondFloor3);
        Sfloor3.setPosition(new Vec2(0f, 0.5f));
        Sfloor3.setFillColor(Color.cyan.darker());

        Shape secondFloor4 = new BoxShape(3.5f, 0.5f);
        StaticBody Sfloor4= new StaticBody(w, secondFloor4);
        Sfloor4.setPosition(new Vec2(8.5f, 0.5f));
        Sfloor4.setFillColor(Color.cyan.darker());


        Shape firstFloor0 = new BoxShape(3.5f, 0.5f);
        StaticBody Ffloor0= new StaticBody(w, firstFloor0);
        Ffloor0.setPosition(new Vec2(-8.5f, -5.5f));
        Ffloor0.setFillColor(Color.cyan.darker());

        Shape firstFloor1 = new BoxShape(2, 0.5f);
        StaticBody Ffloor1= new StaticBody(w, firstFloor1);
        Ffloor1.setPosition(new Vec2(-1f, -5.5f));
        Ffloor1.setFillColor(Color.cyan.darker());


        Shape firstFloor4 = new BoxShape(3.5f, 0.5f);
        StaticBody Ffloor4= new StaticBody(w, firstFloor4);
        Ffloor4.setPosition(new Vec2(8.5f, -5.5f));
        Ffloor4.setFillColor(Color.cyan.darker());




    }

    /*Creates a variable with the Shape Object type and instantiates with the "new" keyword
   and initialises by calling the BoxShape constructor which will set the coordinates of the shape*/
    private static final Shape plat3 = new BoxShape(12f, 0.5f);





}
