package game.Construnction;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;

import java.awt.*;

//Creates a class called Platform_Level1 which extends attributes from the StaticBody class
public class Platform_Level1 extends StaticBody {


    //Creates a constructor which will receive a variable of type World
    public Platform_Level1(World w) {

        super(w,platform);//It calls a constructor from the StaticBody class and attaches the world with the platform shape

        setFillColor(Color.green.darker().darker());//sets the color of the platform

       /*Creates a variable with the Shape Object type and instantiates with the "new" keyword
        and initialises by called the BoxShape constructor and creates another object of type Static body.
        Also applies a color to the platforms.*/

        Shape structure = new BoxShape(1.5f, 0.5f);
        StaticBody base = new StaticBody(w, structure);
        base.setPosition(new Vec2(-10.5f, -8.5f));
        base.setFillColor(Color.green.darker().darker());


        StaticBody base1 = new StaticBody(w, structure);
        base1.setPosition(new Vec2(-1.5f, -6f));
        base1.setFillColor(Color.green.darker().darker());

        Shape structure1 = new BoxShape(5.5f, 0.5f);
        StaticBody base2 = new StaticBody(w, structure1);
        base2.setPosition(new Vec2(-6.5f, 1f));
        base2.setFillColor(Color.green.darker().darker());



        Shape structure2 = new BoxShape(2.5f, 0.5f);
        StaticBody base4 = new StaticBody(w, structure2);
        base4.setPosition(new Vec2(8.5f, -3f));
        base4.setFillColor(Color.green.darker().darker());

        Shape structure3 = new BoxShape(2.5f, 0.5f);
        StaticBody base5 = new StaticBody(w, structure3);
        base5.setPosition(new Vec2(4f, 1.5f));
        base5.setFillColor(Color.green.darker().darker());

        Shape structure4 = new BoxShape(0.5f, 0.5f);
        StaticBody base04 = new StaticBody(w, structure4);
        base04.setPosition(new Vec2(12, 0));
        base04.setFillColor(Color.pink.darker());

        Shape structure6 = new BoxShape(0.5f, 0.5f);
        StaticBody base6 = new StaticBody(w, structure6);
        base6.setPosition(new Vec2(10f, -1.5f));
        base6.setFillColor(Color.pink.darker());

        Shape structure9 = new BoxShape(0.5f, 0.5f);
        StaticBody base9 = new StaticBody(w, structure9);
        base9.setPosition(new Vec2(2f, -4.5f));
        base9.setFillColor(Color.pink.darker());

        Shape structure7 = new BoxShape(0.5f, 0.5f);
        StaticBody base7 = new StaticBody(w, structure7);
        base7.setPosition(new Vec2(-5f, -7));
        base7.setFillColor(Color.pink.darker());

        Shape structure8 = new BoxShape(0.5f, 0.5f);
        StaticBody base8 = new StaticBody(w, structure8);
        base8.setPosition(new Vec2(-8f, -10f));
        base8.setFillColor(Color.pink.darker());

    }

    /*Creates a variable with the Shape Object type and instantiates with the "new" keyword
    and initialises by calling the BoxShape constructor which will set the coordinates of the shape*/
    private static final Shape platform = new BoxShape(12, 0.5f);






}
