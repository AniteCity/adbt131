package game.Construnction;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import city.cs.engine.World;
import org.jbox2d.common.Vec2;

import java.awt.*;


//Creates a class called Platform_Level2 which extends attributes from the StaticBody class
public class Platform_Level2 extends StaticBody{


    //Creates a constructor which will receive a variable of type World
    public Platform_Level2(World w) {

        super(w,plat2);//It calls a constructor from the StaticBody class and attaches the world with the platform shape
        setFillColor(Color.lightGray);//sets the color of the platform

        /*Creates a variable with the Shape Object type and instantiates with the "new" keyword
        and initialises by called the BoxShape constructor and creates another object of type Static body.
        Also applies a color to the platforms.*/

        Shape firstFloor = new BoxShape(2, 0.5f);
        StaticBody floor1 = new StaticBody(w, firstFloor);
        floor1.setPosition(new Vec2(-9f, -5.5f));
        floor1.setFillColor(Color.lightGray);

        Shape firstSecondPlatform = new BoxShape(3.8f, 0.5f);
        StaticBody floor1SecondPlat = new StaticBody(w, firstSecondPlatform);
        floor1SecondPlat.setPosition(new Vec2(1, -5.5f));
        floor1SecondPlat.setFillColor(Color.lightGray);

        Shape firstThirdPlatform = new BoxShape(2f, 0.5f);
        StaticBody floor1ThirdPlat = new StaticBody(w, firstThirdPlatform);
        floor1ThirdPlat.setPosition(new Vec2(9f, -5.5f));
        floor1ThirdPlat.setFillColor(Color.lightGray);

        Shape secondThirdPlatform = new BoxShape(5f, 0.5f);
        StaticBody floor2ThirdPlat = new StaticBody(w, secondThirdPlatform);
        floor2ThirdPlat.setPosition(new Vec2(6f, 0.5f));
        floor2ThirdPlat.setFillColor(Color.lightGray);

        Shape secondFirstPlatform = new BoxShape(3f, 0.5f);
        StaticBody floor2FirstPlat = new StaticBody(w, secondFirstPlatform);
        floor2FirstPlat.setPosition(new Vec2(-8f, 0.5f));
        floor2FirstPlat.setFillColor(Color.lightGray);


        Shape secondSecondPlatform = new BoxShape(0.5f, 0.5f);
        StaticBody floor2SecondPlat = new StaticBody(w, secondSecondPlatform);
        floor2SecondPlat.setPosition(new Vec2(-2, 0.5f));
        floor2SecondPlat.setFillColor(Color.lightGray);




    }

    /*Creates a variable with the Shape Object type and instantiates with the "new" keyword
    and initialises by calling the BoxShape constructor which will set the coordinates of the shape*/
    private static final Shape plat2 = new BoxShape(12, 0.5f);


}
