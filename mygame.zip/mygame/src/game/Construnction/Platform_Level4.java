package game.Construnction;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import city.cs.engine.World;
import org.jbox2d.common.Vec2;

import java.awt.*;

//Creates a class called Platform_Level4 which extends attributes from the StaticBody class
public class Platform_Level4 extends StaticBody {

    //Creates a constructor which will receive a variable of type World
    public Platform_Level4(World w) {

        super(w,plat4);//It calls a constructor from the StaticBody class and attaches the world with the platform shape
        setFillColor(Color.pink.darker());//sets the color of the platform

        /*Creates a variable with the Shape Object type and instantiates with the "new" keyword
        and initialises by called the BoxShape constructor and creates another object of type Static body.
        Also applies a color to the platforms.*/

        Shape firstFloor1 = new BoxShape(5, 0.5f);
        StaticBody Ffloor1= new StaticBody(w, firstFloor1);
        Ffloor1.setPosition(new Vec2(-7, -5.5f));
        Ffloor1.setFillColor(Color.pink.darker());

        Shape firstFloor2 = new BoxShape(3, 0.5f);
        StaticBody Ffloor2= new StaticBody(w, firstFloor2);
        Ffloor2.setPosition(new Vec2(3, -5.5f));
        Ffloor2.setFillColor(Color.pink.darker());

        Shape firstFloor3 = new BoxShape(1, 0.5f);
        StaticBody Ffloor3= new StaticBody(w, firstFloor3);
        Ffloor3.setPosition(new Vec2(11, -5.5f));
        Ffloor3.setFillColor(Color.pink.darker());

        Shape secondFloor0 = new BoxShape(5, 0.5f);
        StaticBody Sfloor0= new StaticBody(w, secondFloor0);
        Sfloor0.setPosition(new Vec2(-7, 0.5f));
        Sfloor0.setFillColor(Color.pink.darker());

        Shape secondFloor1 = new BoxShape(1, 0.5f);
        StaticBody Sfloor1= new StaticBody(w, secondFloor1);
        Sfloor1.setPosition(new Vec2(1, 0.5f));
        Sfloor1.setFillColor(Color.pink.darker());

        Shape secondFloor2 = new BoxShape(2.5f, 0.5f);
        StaticBody Sfloor2= new StaticBody(w, secondFloor2);
        Sfloor2.setPosition(new Vec2(9.5f, 0.5f));
        Sfloor2.setFillColor(Color.pink.darker());

        Shape ThirdFloor0 = new BoxShape(2f, 0.5f);
        StaticBody Tfloor0 = new StaticBody(w, ThirdFloor0);
        Tfloor0.setPosition(new Vec2(6, 6.5f));
        Tfloor0.setFillColor(Color.pink.darker());

        Shape ThirdFloor1 = new BoxShape(5, 0.5f);
        StaticBody Tfloor1= new StaticBody(w, ThirdFloor1);
        Tfloor1.setPosition(new Vec2(-7, 6.5f));
        Tfloor1.setFillColor(Color.pink.darker());








    }

     /*Creates a variable with the Shape Object type and instantiates with the "new" keyword
    and initialises by calling the BoxShape constructor which will set the coordinates of the shape*/

    private static final Shape plat4 = new BoxShape(12f, 0.5f);





}
