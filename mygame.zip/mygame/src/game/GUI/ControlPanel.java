package game.GUI;

import game.Game;
import game.Levels.GameWorld;
import game.Sounds.Sounds;

import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;

/**
 * This class is responsible to create Control panel on a GUI of the game where the user can save,load,turn the
 * sound off/on and quit the game.
 *
 * @author Anite Cangi
 * @version 1.0
 * @see game.View.GameView
 * @see GameWorld
 */
public class ControlPanel {

    //Declaring variables
    private JPanel mainPanel;
    private JButton playButton;
    private JButton quitButton;
    private JCheckBox allSoundBox;
    private JButton nextLevelButton;
    private JButton loadLevelButton;
    private JButton saveLevelButton;
    private Game game;
    private float volume=0.080f;
    private Sounds sounds;
    private int checked;
    private GameWorld level;
    private int tickbox=0;


    //Creates a constructor which will receive variables of type Game,Sound and GameWorld.
    /**
     * The ControlPanel is a constructor which is responsible to obtain the properties from the Game, Sounds and
     * GameWorld class.
     *
     * @param g It obtains the Game properties class.
     * @param s It obtains the Sounds properties class.
     * @param l It obtains the GameWorld properties class.
     */
    public ControlPanel(Game g, Sounds s, GameWorld l) {

        game=g;
        sounds=s;
        level = l;


        //Checks if the button was pressed
        playButton.addActionListener(new ActionListener() {
            /**The actionPerformed method is responsible for checking if any sort of interaction happened with the button
             * called playButton.
             * Once the button is pressed the frame will close, resume the game and check if the tickbox was ticked/not
             * ticked to unable or able the sound of the game.
             *
             * @param e It receives a value if an action is performed.
             */
            public void actionPerformed(ActionEvent e){


                level.getFrame2().setVisible(false);//Take focus from the Frame 2 window
                game.gameResume();  // Resume the game

                //Check if the tick box was ticked or not to mute/play the sound
                if(getTickbox()==0) {
                    game.getGameMusic().play();
                }else if(getTickbox()==1){
                    game.getGameMusic().stop();
                    level.getSounds().stopJumpSound();
                }
                checked=0;



            }
        });


        //Checks if the Quit button was pressed to exit the game
        quitButton.addActionListener(new ActionListener() {
            /**The actionPerformed method is responsible for checking if any sort of interaction happened with the button
             * called quitButton to quit the game.
             * If the button is pressed a method will be called to quit the game.
             *
             * @param e It receives a value if an action is performed.
             */
            public void actionPerformed(ActionEvent e){

                game.gameQuit();

            }
        });


        //Check if the Tickbox was ticked or not
        allSoundBox.addActionListener(new ActionListener() {
            /**The actionPerformed method is responsible for checking if any sort of interaction happened with the tick box
             * called allSoundBox to mute/play all the background sound.
             * Once the box is ticked is pressed the a value will be set to 1 showing that it was ticked and 0 otherwise.
             *
             * @param e It receives a value if an action is performed.
             */
            @Override
            public void actionPerformed(ActionEvent e) {


                if(tickbox==0){
                    System.out.println("Ticked");
                    tickbox=1;
                }else if(tickbox==1){

                    System.out.println("not ticked");
                    tickbox=0;
                }


            }
        });


        /*If next Level button is clicked then it will send a true value to the goToNextLevel method
         and change the world*/
        nextLevelButton.addActionListener(new ActionListener() {

            /**The actionPerformed method is responsible for checking if any sort of interaction happened with the button
             * called nextLevelButton to shift to the next level.
             * Once the button is pressed the goToNextLevel method will be called setting the key as true.
             *
             * @param e It receives a value if an action is performed.
             */
            public void actionPerformed(ActionEvent e) {

                game.goToNextLevel(true);

                System.out.println("Loading...");




            }
        });


         /*Button to save the level inside a file*/
        saveLevelButton.addActionListener(new ActionListener() {
            /**The actionPerformed method is responsible for checking if any sort of interaction happened with the button
             * called saveLevelButton to save the level.
             * Once the button is pressed the SaverLoader.Save method will be called saving the data in a file.
             *
             *
             * @param e It receives a value if an action is performed.
             */
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    SaverLoader.save(game.getLevel(),"data/save.txt");
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                System.out.println("save");

            }
        });


        //Button to load the level and set the level from the saved level inside the file.
        loadLevelButton.addActionListener(new ActionListener() {
            /**
             The actionPerformed method is responsible for checking if any sort of interaction happened with the button
             * called loadLevelButton to load the level.
             * Once the button is pressed the SaverLoader.Load method will be called loading the data from a file and
             * set the current level to be the level saved inside the file.
             *
             * @param e It receives a value if an action is performed.
             */
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    GameWorld level= SaverLoader.load(game,"data/save.txt");

                    game.setLevel(level);

                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                System.out.println("load");
            }
        });
    }


    //Getter method for the Tickbox variable
    /**
     * The getTickbox is a getter method which return the tickbox variable.
     *
     * @return It returns the tickbox value.
     */
    public int getTickbox() {
        return tickbox;
    }


    //Setter method for the checked variable
    /**
     * The setChecked is a setter method which will set the value of the variable checked.
     *
     * @param checked It obtains a value to attach it to the local checked variable.
     * */
    public void setChecked(int checked) {
        this.checked = checked;
    }


    //Getter method for the checked variable
    /**
     * The getChecked is a getter method which return the checked variable.
     *
     * @return It returns the checked value.
     */
    public int getChecked() {
        return checked;
    }

    //Getter method for the mainPanel variable

    /**
     * The getMainPanel method is a getter method to return the mainPanel Object
     *
     * @return It returns the mainPanel Object.
     */
    public JPanel getMainPanel() {
        return mainPanel;
    }

    /**
     * Method to create create UI Components.
     */
    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
