package game.GUI;

import game.Game;
import game.Levels.*;
import org.jbox2d.common.Vec2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class SaverLoader {

    //Declaring variables
   private static int thunderCount;
    private static int lifeCount;
    private static float hero1PositionX;
    private static float hero1PositionY;
    private static float Enemy1PositionX;
    private static float Enemy1PositionY;
    private static float Enemy2PositionX;
    private static float Enemy2PositionY ;
    private static float Enemy2DirectionSpeed;
    private static float Spike1PositionX;
    private static float Spike1PositionY;
    private static float Spike2PositionX;
    private static float Spike2PositionY;
    private static float Spike3PositionX;
    private static float Spike3PositionY;


    //Creating a method to save the game from a file
    public static void save(GameWorld level, String fileName)
            throws IOException
     {
            boolean append = false;
            FileWriter writer = null;
            try {
                writer = new FileWriter(fileName, append);  //writes to the file
                if(level.getLevelName()=="Level4") {

                    /*Write the position of the Hero1, Enemy1, Enemy2, Score, position of the movingSpikes and their
                    * speeds inside a file.*/

                    writer.write(level.getLevelName() + "," + level.getHero1().getThunderCount() + "," +
                            level.getGame().getView().getNoOfLife() + "," + level.getHero1().getPosition().x + ","
                            + level.getHero1().getPosition().y + "," + level.getEnemy1().getPosition().x + ","
                            + level.getEnemy1().getPosition().y + "," + level.getOnlyEnemy2().getPosition().x + ","
                            + level.getOnlyEnemy2().getPosition().y +","+level.getEnemy2Speed()+","+
                            level.getOnlyMovingSpike1().getPosition().x+","+level.getOnlyMovingSpike1().getPosition().y+","+
                            level.getOnlyMovingSpike2().getPosition().x+","+level.getOnlyMovingSpike2().getPosition().y+","+
                            level.getOnlyMovingSpike3().getPosition().x+","+level.getOnlyMovingSpike3().getPosition().y+","+

                            "\n");
                }else if(level.getLevelName()=="Level3"){

                    /*Write the position of the Hero1, Enemy1, Score, position of the movingSpikes and their
                     * speeds inside a file.*/
                    writer.write(level.getLevelName() + "," + level.getHero1().getThunderCount() + "," +
                            level.getGame().getView().getNoOfLife() + "," + level.getHero1().getPosition().x + ","
                            + level.getHero1().getPosition().y + "," + level.getEnemy1().getPosition().x + ","
                            + level.getEnemy1().getPosition().y + "," +

                            level.getOnlyMovingSpike1().getPosition().x+","+level.getOnlyMovingSpike1().getPosition().y+","+
                            level.getOnlyMovingSpike2().getPosition().x+","+level.getOnlyMovingSpike2().getPosition().y+","+
                           level.getOnlyMovingSpike3().getPosition().x+","+level.getOnlyMovingSpike3().getPosition().y+

                            "\n");
                }else if(level.getLevelName()=="Level2"){

                    /*Write the position of the Hero1, Enemy1, Score and their
                     * speeds inside a file.*/

                    writer.write(level.getLevelName() + "," + level.getHero1().getThunderCount() + "," +
                            level.getGame().getView().getNoOfLife() + "," + level.getHero1().getPosition().x + ","
                            + level.getHero1().getPosition().y + "," + level.getEnemy1().getPosition().x + ","
                            + level.getEnemy1().getPosition().y +"\n");
                }else if(level.getLevelName()=="Level1"){

                    /*Write the position of the Hero1, Enemy1, Score and their
                     * speeds inside a file.*/
                    writer.write(level.getLevelName() + "," + level.getHero1().getThunderCount() + "," +
                            level.getGame().getView().getNoOfLife() + "," + level.getHero1().getPosition().x + ","
                            + level.getHero1().getPosition().y + "," + level.getEnemy1().getPosition().x + ","
                            + level.getEnemy1().getPosition().y +"\n");
                }
            } finally {
                if (writer != null) {
                    writer.close();//close the file
                }
            }

    }

    //Creating a method to load the game from a file
    public static GameWorld load(Game game , String fileName)
            throws IOException {
        FileReader fr = null;
        BufferedReader reader = null;
        try {
            System.out.println("Reading " + fileName + " ...");
            fr = new FileReader(fileName);//reads the file
            reader = new BufferedReader(fr);
            String line = reader.readLine();//Reads the line
            String[] tokens = line.split(","); //splits and adds to the array once it reaches a comma
            String name = tokens[0];



            GameWorld level = null;//sets the level to be null
            if (name.equals("Level1")) {

                /*Sets the level to be Level1 and reads all the other elements from the array and sets them on the
                * level*/
                level = new Level1(game);
                thunderCount = Integer.parseInt(tokens[1]);
                 lifeCount = Integer.parseInt(tokens[2]);
                 hero1PositionX = Float.parseFloat(tokens[3]);
                 hero1PositionY = Float.parseFloat(tokens[4]);
                 Enemy1PositionX = Float.parseFloat(tokens[5]);
                 Enemy1PositionY = Float.parseFloat(tokens[6]);
                level.getView().setLevelName("Level 1");
                //sets the score and the position of the hero1 and the enemy1
                level.getHero1().setThunderCount(thunderCount);
                level.getHero1().setPosition(new Vec2(hero1PositionX, hero1PositionY));
                level.getEnemy1().setPosition(new Vec2(Enemy1PositionX, Enemy1PositionY));


            } else if (name.equals("Level2")) {

                /*Sets the level to be Level2 and reads all the other elements from the array and sets them on the
                 * level*/
                level = new Level2(game);
                thunderCount = Integer.parseInt(tokens[1]);
                lifeCount = Integer.parseInt(tokens[2]);
                hero1PositionX = Float.parseFloat(tokens[3]);
                hero1PositionY = Float.parseFloat(tokens[4]);
                Enemy1PositionX = Float.parseFloat(tokens[5]);
                Enemy1PositionY = Float.parseFloat(tokens[6]);
                level.getView().setLevelName("Level 2");
                //sets the score and the position of the hero1 and the enemy1
                level.getHero1().setThunderCount(thunderCount);
                level.getHero1().setPosition(new Vec2(hero1PositionX, hero1PositionY));
                level.getEnemy1().setPosition(new Vec2(Enemy1PositionX, Enemy1PositionY));


            } else if (name.equals("Level3")){

                /*Sets the level to be Level3 and reads all the other elements from the array and sets them on the
                 * level*/

                level = new Level3(game);
                thunderCount = Integer.parseInt(tokens[1]);
                lifeCount = Integer.parseInt(tokens[2]);
                hero1PositionX = Float.parseFloat(tokens[3]);
                hero1PositionY = Float.parseFloat(tokens[4]);
                Enemy1PositionX = Float.parseFloat(tokens[5]);
                Enemy1PositionY = Float.parseFloat(tokens[6]);
                Spike1PositionX = Float.parseFloat(tokens[7]);
                Spike1PositionY = Float.parseFloat(tokens[8]);
                Spike2PositionX = Float.parseFloat(tokens[9]);
                Spike2PositionY = Float.parseFloat(tokens[10]);
                Spike3PositionX = Float.parseFloat(tokens[11]);
                Spike3PositionY = Float.parseFloat(tokens[12]);
                level.getView().setLevelName("Level 3");

                //sets the score,the position of the hero1,the enemy1 and the moving spikes
                level.getHero1().setThunderCount(thunderCount);
                level.getHero1().setPosition(new Vec2(hero1PositionX, hero1PositionY));

                level.getOnlyMovingSpike1().setPosition(new Vec2(Spike1PositionX, Spike1PositionY));
                level.getOnlyMovingSpike2().setPosition(new Vec2(Spike2PositionX, Spike2PositionY));
                level.getOnlyMovingSpike3().setPosition(new Vec2(Spike3PositionX, Spike3PositionY));




            }else if (name.equals("Level4")){

                /*Sets the level to be Level4 and reads all the other elements from the array and sets them on the
                 * level*/

            level = new Level4(game);
                thunderCount = Integer.parseInt(tokens[1]);
                lifeCount = Integer.parseInt(tokens[2]);
                hero1PositionX = Float.parseFloat(tokens[3]);
                hero1PositionY = Float.parseFloat(tokens[4]);
                Enemy1PositionX = Float.parseFloat(tokens[5]);
                Enemy1PositionY = Float.parseFloat(tokens[6]);
                Enemy2PositionX = Float.parseFloat(tokens[7]);
                Enemy2PositionY = Float.parseFloat(tokens[8]);
                Enemy2DirectionSpeed = Float.parseFloat(tokens[9]);
                Spike1PositionX = Float.parseFloat(tokens[10]);
                Spike1PositionY = Float.parseFloat(tokens[11]);
                Spike2PositionX = Float.parseFloat(tokens[12]);
                Spike2PositionY = Float.parseFloat(tokens[13]);
                Spike3PositionX = Float.parseFloat(tokens[14]);
                Spike3PositionY = Float.parseFloat(tokens[15]);
                level.getView().setLevelName("Level 4");
                //sets the score,the position of the hero1,the enemy1, Enemy2 and the moving spikes
                level.getHero1().setThunderCount(thunderCount);
                level.getHero1().setPosition(new Vec2(hero1PositionX, hero1PositionY));
                level.getEnemy1().setPosition(new Vec2(Enemy1PositionX, Enemy1PositionY));
                level.getOnlyEnemy2().setPosition(new Vec2(Enemy2PositionX, Enemy2PositionY));

                level.getOnlyMovingSpike1().setPosition(new Vec2(Spike1PositionX, Spike1PositionY));
                level.getOnlyMovingSpike2().setPosition(new Vec2(Spike2PositionX, Spike2PositionY));
                level.getOnlyMovingSpike3().setPosition(new Vec2(Spike3PositionX, Spike3PositionY));


                level.setEnemy2Speed(Enemy2DirectionSpeed);
                level.setEnemy2Walking(Enemy2DirectionSpeed);

          }



                //Sets the icons of life on the screen
                if(lifeCount==1){

                    level.getHero1().setLivesCount(1);
                    level.getGame().getView().set1Lives();

                }else if(lifeCount==2){

                    level.getHero1().setLivesCount(2);
                    level.getGame().getView().set2Lives();

                }else if(lifeCount==3){

                    level.getHero1().setLivesCount(3);
                    level.getGame().getView().set3Lives();
                }

            return level;   //returns back the level.

        } finally {
            if (reader != null) {
                reader.close();//closes the file
            }
            if (fr != null) {
                fr.close();//closes the file
            }
        }
    }
}
