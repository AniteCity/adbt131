package game.GUI;



import java.io.FileWriter;
import java.io.IOException;

/**
 * Demonstrates how high-score data can be written to a text file.
 */
public class BestScoreWriter {

    //Declares a variable
    private String fileName;

    //Setter for the filename.
    public BestScoreWriter(String fileName) {
        this.fileName = fileName;
    }

    //BestScoreWriter's constructor
    public void writeHighScore(String name, int score) throws IOException {
        boolean append = true;
        FileWriter writer = null;
        try {
            writer = new FileWriter(fileName, append);//writes inside the file
            writer.write(name + "," + score + "\n");//write by separating with a comma.
        } finally {
            if (writer != null) {
                writer.close();//close the file.
            }
        }
    }

    public static void main(String[] args) throws IOException {
        BestScoreWriter hsWriter = new BestScoreWriter("sample.hs");
        for (int i = 0; i < args.length; i += 2) {
            String name = args[i];
            int score = Integer.parseInt(args[i + 1]);
            hsWriter.writeHighScore(name, score);
        }
    }
}