package game.GUI;

import game.Game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class BestScore {
    private JPanel pnlScore;
    private JPanel pnlControls;
    private JLabel labelPlayerName;
    private JTextField txtName;
    private JLabel labelScoreTitle;
    private JLabel LabelScore;
    private JButton btnSave;
    private JButton btnCancel;
    private JList<String> listScores;
    private JScrollPane scrScores;
    private Game game;
    private BestScoreWriter highScoreWriter;
    private BestScoreReader bestScoreReader;
    private final String fileName ="highScores.txt";

    //creating a constructor for the Best score.
    public BestScore(Game game){

        this.game=game;

        //setting the text label of the score
        LabelScore.setText(game.getLevel().getHero1().getThunderCount()+"");

        //creating a new file
        File scores = new File(fileName);

        try{
            scores.createNewFile();
        }catch (IOException ex){
            ex.printStackTrace();
        }

        //creating a BestScoreWriter and BestScoreReader objects.
        highScoreWriter = new BestScoreWriter(fileName);
        bestScoreReader = new BestScoreReader(fileName);


        /*If button Save is pressed then it will save the score of the player inside a file*/
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{

                    highScoreWriter.writeHighScore(txtName.getText(), game.getLevel().getHero1().getThunderCount());

                }catch (IOException ex){

                    ex.printStackTrace();

                }
                System.exit(0);
            }
        });

        //If the cancel button is pressed then the game will quit.
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                System.exit(0);
            }
        });


        //creating a list
        DefaultListModel<String> model = new DefaultListModel<>();

        try{
         model.addAll(BestScoreReader.readScores());

        } catch (IOException ex){

            ex.printStackTrace();
        }

        listScores.setModel(model);


    }


    //Getter method to get the scores from the panel
    public  JPanel getJpanelScores(){

        return pnlScore;
    }


}
