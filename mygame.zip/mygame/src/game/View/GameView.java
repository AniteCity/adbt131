package game.View;
import city.cs.engine.UserView;
import city.cs.engine.World;
import game.GUI.ControlPanel;
import game.GameCharacters.Hero1;
import game.Levels.GameWorld;

import javax.swing.*;
import java.awt.*;

//Creates a class called GameView which extends attributes from the UserView class

/**
 * This class is responsible to create a new GameView to add additional properties on the screen
 * such as the player's score, health and score.
 *
 * @author Anite Cangi
 * @version 1.0
 * @see GameWorld
 * @see game.Shoot.Shooting
 */
public class GameView extends UserView {

    //Declaring variables
    private Image background;
    private Hero1 hero1;
    private GameWorld level;
    private Image heart1;
    private Image heart2;
    private Image heart3;
    private Image heartArray[];
    private Image flamesArray[];
    private Image key;
    private Image flame;
    private int noOfLife=3;
    private String name="Level 1";

    /*Creates a constructor which will receive the World variable, the height, the width, the hero and the gameworld
    * type variable*/

    /**
     * The GameView is a constructor which will obtain values from other classes such as World, Width value, Height value,
     * Hero1 Object and a GameWorld Object to have access to them.
     *
     * @param w It receives the World object.
     * @param width It receives the width object.
     * @param height It receives the height value.
     * @param hero1 It receives the hero1 value.
     * @param level It receives the level object.
     */
    public GameView(World w, int width, int height, Hero1 hero1,GameWorld level) {

        /*It calls a constructor from the UserView class and attaches the World with with height and the with of the
        game view*/

        super(w, width, height);

        this.level=level;
        this.hero1=hero1;

        //initialises the objects
        background= new ImageIcon("data/background.gif").getImage();
        heart1= new ImageIcon("data/heart.png").getImage();
        heart2=new ImageIcon("data/heart.png").getImage();
        heart3=new ImageIcon("data/heart.png").getImage();
        heartArray=new Image[] {heart1,heart2,heart3 };
        key = new ImageIcon("").getImage();
        flame = new ImageIcon("").getImage();
        flamesArray = new Image[] {flame};

        }



    //This overrides the "paintBackground" method

    /**
     * The paintBackground method is responsible to attach the background to the game.
     *
     * @param g It receives a value of type Graphics2D.
     */
    @Override
    /*Creates a method which will get a variable of type Graphics2D which will be responsible for
    changing the background */

    protected void paintBackground(Graphics2D g) {
        g.drawImage(background,0,0,this);
    }

    //Setter method for the background variable
    /**
     * The setBackground is a setter method to set the local variable background.
     *
     * @param background It receives a variable Image type variable.
     */
    public void setBackground(Image background) {
        this.background = background;
    }


    //Displays the score of the Hero1
    /**
     * The paintForeground method is responsible to display the score of the player on the game screen, attach
     * a color and a size.
     *
     * @param g It receives a value of type Graphics2D.
     */
    @Override
    protected void paintForeground(Graphics2D g){

        //Sets a text font for the Score string
        g.setFont(new Font("serif", Font.BOLD, 30));
        g.drawString("Score: "+ this.hero1.getThunderCount(),380,35);
        g.drawString(this.name,190,35);
        g.setColor(Color.white);



        //Draws the heart images
        for (int i = 0; i < heartArray.length; i++) {

            g.drawImage(heartArray[i],i+(i*30),5,this);

        }


        //Draws the key icon and the flame icon
        g.drawImage(key,100,5,this);
        g.drawImage(flame,350,5,this);


    }

    //Method that displays the name of the Level
    /**
     * Setter method for the name of the level.
     *
     * @param name It receives a String.
     */
    public void setLevelName(String name) {

        this.name=name;

    }

    //setter for the flame icon
    /**
     * The setFlameIcon is a method to attach an image of flame everytime is method is called.
     *
     */
    public void setFlameIcon() {

        this.flame = new ImageIcon("data/paintFlame.png").getImage() ;

    }

    //Method to remove the flame icon
    /**
     * The removeFlameIcon method removes the image from the the screen once its called.
     *
     */
    public void removeFlameIcon() {

        flame = new ImageIcon("").getImage() ;

    }


    //Method to draw 0 hearts
    /**
     * The set0Lives method is responsible to set an array with 0 elements to not display any images.
     *
     */
    public void set0Lives() {
        heartArray=new Image[] { };
        noOfLife=0;

    }

    //Method to draw 1 hearts
    /**
     * The set1Lives method is responsible to set an array with 1 element to display only 1 image.
     *
     */
    public void set1Lives() {
        heartArray=new Image[] {heart1 };
        heart1= new ImageIcon("data/heart.png").getImage();

        noOfLife=1;

    }

    //Method to draw 2 hearts
    /**
     * The set2Lives method is responsible to set an array with 2 elements to display only 2 images.
     *
     */
    public void set2Lives() {
        heartArray=new Image[] {heart1,heart2 };
        heart1= new ImageIcon("data/heart.png").getImage();
        heart2=new ImageIcon("data/heart.png").getImage();
        noOfLife=2;
    }

    //Method to draw 3 hearts
    /**
     * The set3Lives method is responsible to set an array with 3 elements to display only 3 images.
     *
     */
    public void set3Lives() {
        heartArray=new Image[] {heart1,heart2,heart3 };
        heart1= new ImageIcon("data/heart.png").getImage();
        heart2=new ImageIcon("data/heart.png").getImage();
        heart3=new ImageIcon("data/heart.png").getImage();
        noOfLife=3;
    }

    //Getter for the number of lives
    /**The getNoOfLife is a getter method which will return the value of the number of lives.
     *
     * @return It returns the noOfLife.
     */
    public int getNoOfLife() {
        return noOfLife;
    }

    //Setter for the flame variable
    /**The setFlame is a setter method which sets the local variable to the value passed.
     *
     * @param flame It receives a value of type Image.
     */
    public void setFlame(Image flame) {
        this.flame = flame;
    }

    //Setter for the Key variable
    /**
     * The setKey method is a setter method to set an image received to the local variable.
     *
     * @param key It receives an value of type Image.
     */
    public void setKey(Image key) {
        this.key = key;
    }



    //Setter for the hero1 variable
    /**
     * The setHero1 method is a setter method which updates the hero1 object.
     *
     * @param hero1 It receives a value of type Hero1.
     */
    public void setHero1(Hero1 hero1) {
        this.hero1 = hero1;
    }


}