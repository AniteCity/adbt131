package game.Ammos;

import city.cs.engine.*;


//Creates a class called Fireball which extends attributes from the Walker class

public class Fireball extends Walker {


    //Creates a constructor which will receive a variable of type World
    public Fireball(World world) {

        super(world,fireball);//It calls a constructor from the Walker class and attaches the fireball shape to the world
        addImage(image);//Attaches an image which is stored in the image variable

    }





    /*Creates variables with the Shape Object type and BodyImage type, instantiates with the "new" keyword
    and initialises by calling the PolygonShape constructor which will set the coordinates of the shape and
    initialises the BodyImage object by calling the BodyImage constructor*/

    private static final Shape fireball
            = new PolygonShape(0.603f,0.456f, 0.591f,-0.429f, -0.603f,-0.441f, -0.597f,0.438f);


    private static final BodyImage image= new BodyImage("data/fireball.gif",1.5f);


    //Creates a method to flip the image horizontally to the left side
    public void flipLeft() {
        addImage(image).flipHorizontal();

    }
    //Creates a method to flip the image horizontally to the Right side
    public void flipRight() {
        addImage(image);

    }



}
