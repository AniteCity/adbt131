package game.Controls;

import game.Collectable.Fire;
import game.GUI.ControlPanel;
import game.Game;
import game.GameCharacters.Hero1;
import game.Levels.GameWorld;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Keyboard implements KeyListener {

    //Declaring all the variables
    private float speed = 5;
    private float jumpspeed = 5.8f;
    private Hero1 hero1;
    private GameWorld level;
    private Game game;
    private Fire fire;
    private ControlPanel controlPanel;
    private int press;
    private int check;
    public int paused;


    //Creates a constructor which will receive variables of type Hero1,GameWorld,Game,ControlPanel and Frame.
    public Keyboard(Hero1 body, GameWorld w, Game g, ControlPanel panel, Frame f) {
        hero1 = body;
        level=w;
        game=g;
        controlPanel=panel;
    }

    //This overrides the "KeyTyped" method from the KeyListener Class
    @Override
    public void keyTyped(KeyEvent e) {

    }

    //This overrides the "keyPressed" method from the KeyListener Class
    @Override

    /*This method receives a variable of type KeyEvent which will be the key pressed on the keyboard*/
    public void keyPressed(KeyEvent e) {

        press = e.getKeyCode();//Stores the key pressed on the keyboard inside a variable

        /*Checks if the Key "A" or Key "D" was pressed to decrease/increase the speed which will cause the Hero1 to move in
         the opposite direction and it will remove all the images attached to the Hero1 so it can call a method
          which will add the image to the Hero1 again and flip it */
        if (press == KeyEvent.VK_A) {

            hero1.startWalking(-speed);

            hero1.removeAllImages();
            hero1.flipLeft();
            check=1;

        } else if (press == KeyEvent.VK_D) {

            hero1.startWalking(speed);
            hero1.removeAllImages();
            hero1.flipRight();
            check=0;


        /*If the Key "W" is pressed then the Hero1 will jump*/
        } else if (press == KeyEvent.VK_W) {

            if(controlPanel.getChecked()==1){

                this.level.getSounds().stopJumpSound();


            }else{
                //Checks if the tick box was ticked to mute/play the sound
                if (controlPanel.getTickbox() == 0) {

                    this.level.getSounds().playJumpSound();

                }else if (controlPanel.getTickbox() == 1) {

                    this.level.getSounds().stopJumpSound();
                }

            }


            //sets the speed of the jump
            hero1.jump(jumpspeed);


        /*If the Key "SPACE" is pressed then the Hero1 shoot a fireball*/
        }else if (press == KeyEvent.VK_SPACE) {


            /*Checks which way the player is facing to shoot in the direction of the player */
            if( check == 1 && level.getFireCount()>0)
            {

                //Checks if the tick box was ticked to mute/play the sound
                if(level.getButtons().getTickbox()==0 ){

                    level.getSounds().playShootingSound();

                }else if(level.getButtons().getTickbox()==1){

                    level.getSounds().stopShootingSound();
                }

                //Creates fireBalls by calling a method
                level.createFireballs();

                //Decreases the value of fire count variable
                level.decreaseFireCount();

                //Once the player has spent all the Fireball the Fire icon will be removed
                if(level.getFireCount()==0){

                    game.getView().removeFlameIcon();

                }

            /*Checks which way the player is facing to shoot in the direction of the player */
            }else if (check == 0 && level.getFireCount()>0){

                //Checks if the tick box was ticked to mute/play the sound
                if(level.getButtons().getTickbox()==0 ){

                    level.getSounds().playShootingSound();

                }else if(level.getButtons().getTickbox()==1){

                    level.getSounds().stopShootingSound();
                }

                //Decreases the value of fire count variable
                level.decreaseFireCount();

                //Creates fireBalls by calling a method
                level.createFireballsOpposite();


                //Once the player has spent all the Fireball the Fire icon will be removed
                if(level.getFireCount()==0){

                    game.getView().removeFlameIcon();

                }
            }

         /*If the Key "P" is pressed then game will pause*/
        }else if (press == KeyEvent.VK_P) {


            /*Check if the pause menu was closed by clicking on the button, by clicking on the X on the window
            or by clicking on again on the key "P"*/

            /*The first time I press P the getCheck variable will have the value 0 so it will run the first
             if statement inside.

             After running the if statement it will set the value of the getCheck to 1
             so next I press the P the get check will be 1.

             Inside each getChekced an if statement will check if the tick box was ticked or not to mute/play
             the sound*/

            if(controlPanel.getChecked()==0 ){



                if(controlPanel.getTickbox()==0) {
                    game.gamePause();
                    level.getFrame2().setVisible(true);
                    game.getGameMusic().stop();
                    level.getFrame2().setFocusableWindowState(false);


                }else if(controlPanel.getTickbox()==1) {
                    game.gamePause();
                    level.getFrame2().setVisible(true);
                    game.getGameMusic().stop();
                    level.getFrame2().setFocusableWindowState(false);
                }
                controlPanel.setChecked(1);
            }else if(controlPanel.getChecked()==1 ){

                if(controlPanel.getTickbox()==0) {
                    game.gameResume();
                    level.getFrame2().setVisible(false);
                    game.getGameMusic().play();
                    level.getFrame2().setFocusableWindowState(false);


                }else if(controlPanel.getTickbox()==1){
                    game.gameResume();
                    level.getFrame2().setVisible(false);
                    game.getGameMusic().stop();
                    level.getSounds().stopJumpSound();
                    level.getFrame2().setFocusableWindowState(false);



                }

                controlPanel.setChecked(0);
            }



        }



    }




    //setter method for the Jumpspeed variable
    public void setJumpspeed(float jumpspeed) {
        this.jumpspeed = jumpspeed;
    }






    //This overrides the "keyReleased" method from the KeyListener Class
    @Override

    /*Once the key pressed is released it will be stored in a variable and it will check if
     the key pressed was A or D it will stop moving */
    public void keyReleased(KeyEvent e) {
        press = e.getKeyCode();
        if (press == KeyEvent.VK_A) {
            hero1.stopWalking();
        } else if (press == KeyEvent.VK_D) {
            hero1.stopWalking();
        }
    }
}
